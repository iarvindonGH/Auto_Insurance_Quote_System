package com.aiqs.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.aiqs.bean.UserBean;
import com.aiqs.util.DBConnection;
import com.aiqs.bean.BeanFactory;

public class UserDao {

	static private String UserTable = "aiqs_user_details_tb";

	final private static int colUseridIndex = 1;
	final private static int colFirstNameIndex = 2;
	final private static int colLastNameIndex = 3;
	final private static int colAgeIndex = 4;
	final private static int colGenderIndex = 5;
	final private static int colAddressIndex = 6;
	final private static int colPhoneNoIndex = 7;
	final private static int colEmailIndex = 8;

	final private static String InsertQuery = "INSERT INTO " + UserTable
			+ " VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
	final private static String DeleteQuery = "DELETE FROM " + UserTable
			+ " WHERE user_id = ?";
	final private static String SelectAllUserQuery = "SELECT * FROM "
			+ UserTable;
	final private static String SelectUserQuery = "SELECT * FROM " + UserTable
			+ " WHERE user_id= ?";

	public static String save(final UserBean user) {
		String Response = "error";
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(InsertQuery);
			pstmt.setLong(colUseridIndex, user.getUserId());
			pstmt.setString(colFirstNameIndex, user.getFirstName());
			pstmt.setString(colLastNameIndex, user.getLastName());
			pstmt.setInt(colAgeIndex, user.getAge());
			pstmt.setString(colGenderIndex, user.getGender());
			pstmt.setString(colAddressIndex, user.getAddress());
			pstmt.setString(colEmailIndex, user.getEmail());
			pstmt.setLong(colPhoneNoIndex, user.getPhoneNo());

			DBConnection.beginTransaction();
			int RowAffect = pstmt.executeUpdate();

			if (RowAffect != 0) {
				Response = "success";
			}
			// DBConnection.endTransaction();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}

		return Response;
	}

	public static String delete(final Long userid) {

		final int deleteUserIDIndex = 1;
		String Response = "error";
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(DeleteQuery);
			pstmt.setLong(deleteUserIDIndex, userid);

			DBConnection.beginTransaction();
			int RowAffect = pstmt.executeUpdate();

			if (RowAffect != 0) {
				Response = "success";
			}
			DBConnection.endTransaction();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}

		return Response;
	}

	public static ArrayList<UserBean> findAll() {

		final int findUserID = 1;
		final int findFirstName = 2;
		final int findLastName = 3;
		final int findAge = 4;
		final int findGender = 5;
		final int findAddress = 6;
		final int findPhoneNo = 7;
		final int findEmail = 8;

		UserBean user = null;
		ArrayList<UserBean> UserList = null;
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(
					SelectAllUserQuery);

			ResultSet rs = pstmt.executeQuery();
			UserList = new ArrayList<UserBean>();
			while (rs.next()) {
				user = BeanFactory.getUserBean();

				user.setUserId(rs.getLong(findUserID));
				user.setFirstName(rs.getString(findFirstName));
				user.setLastName(rs.getString(findLastName));
				user.setAge(rs.getInt(findAge));
				user.setGender(rs.getString(findGender));
				user.setEmail(rs.getString(findEmail));
				user.setPhoneNo(rs.getLong(findPhoneNo));
				user.setAddress(rs.getString(findAddress));

				UserList.add(user);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}
		return UserList;
	}

	public static UserBean findById(Long userID) {

		final int updateUserIDIndex = 1;

		UserBean user = null;
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(
					SelectUserQuery);
			pstmt.setLong(updateUserIDIndex, userID);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {

				user = BeanFactory.getUserBean();

				user.setUserId(rs.getLong(colUseridIndex));
				user.setFirstName(rs.getString(colFirstNameIndex));
				user.setLastName(rs.getString(colLastNameIndex));
				user.setAge(rs.getInt(colAgeIndex));
				user.setGender(rs.getString(colGenderIndex));
				user.setEmail(rs.getString(colEmailIndex));
				user.setPhoneNo(rs.getLong(colPhoneNoIndex));
				user.setAddress(rs.getString(colAddressIndex));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}
		return user;
	}

}
