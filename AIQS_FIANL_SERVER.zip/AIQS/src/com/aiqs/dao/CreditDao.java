package com.aiqs.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.aiqs.bean.BeanFactory;
import com.aiqs.bean.CreditBean;
import com.aiqs.util.DBConnection;

public class CreditDao {

	static private String UserTable = "aiqs_credit_details_tb";

	final private static int colPNIIndex = 1;
	final private static int colQuoteIDIndex = 2;
	final private static int colCreditCardTypeIndex = 3;
	final private static int colCreditCardNoIndex = 4;
	final private static int colValidityFromIndex = 5;
	final private static int colValidityToIndex = 6;
	final private static int colBalanceIndex = 7;

	final private static String InsertQuery = "INSERT INTO " + UserTable
			+ " VALUES(?, ?, ?, ?, ?, ?, ?)";
	final private static String SelectUserQuery = "SELECT * FROM " + UserTable
			+ " WHERE quote_id = ?";
	final private static String DeleteQuery = "DELETE FROM " + UserTable
			+ " WHERE pnino = ?";

	public static String save(final CreditBean credit) {
		String Response = "error";
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(InsertQuery);
			pstmt.setLong(colPNIIndex, credit.getPnino());
			pstmt.setLong(colQuoteIDIndex, credit.getQuoteId());
			pstmt.setString(colCreditCardTypeIndex, credit.getCreditCardType());
			pstmt.setLong(colCreditCardNoIndex, credit.getCreditCardNumber());
			pstmt.setDate(colValidityFromIndex, new java.sql.Date(credit
					.getValidityFrom().getTime()));
			pstmt.setDate(colValidityToIndex, new java.sql.Date(credit
					.getValidityTo().getTime()));
			pstmt.setLong(colBalanceIndex, credit.getBalance());

			DBConnection.beginTransaction();
			int RowAffect = pstmt.executeUpdate();

			if (RowAffect != 0) {
				Response = "success";
			}
			DBConnection.endTransaction();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}

		return Response;
	}

	public static CreditBean findById(Long quoteID) {

		final int updateQuoteIDIndex = 1;
		CreditBean credit = null;
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(
					SelectUserQuery);
			pstmt.setLong(updateQuoteIDIndex, quoteID);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				credit = BeanFactory.getCreditBean();
				credit.setPnino(rs.getLong(colPNIIndex));
				credit.setQuoteId(rs.getLong(colQuoteIDIndex));
				credit.setCreditCardType(rs.getString(colCreditCardTypeIndex));
				credit.setCreditCardNumber(rs.getLong(colCreditCardNoIndex));
				credit.setValidityFrom(new java.util.Date(rs.getDate(
						colValidityFromIndex).getTime()));
				credit.setValidityTo(new java.util.Date(rs.getDate(
						colValidityToIndex).getTime()));
				credit.setBalance(rs.getLong(colBalanceIndex));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}
		return credit;
	}

	public static String delete(final Long pnino) {

		final int deletePNIIndex = 1;
		String Response = "error";
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(DeleteQuery);
			pstmt.setLong(deletePNIIndex, pnino);

			DBConnection.beginTransaction();
			int RowAffect = pstmt.executeUpdate();

			if (RowAffect != 0) {
				Response = "success";
			}
			DBConnection.endTransaction();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}

		return Response;
	}

}
