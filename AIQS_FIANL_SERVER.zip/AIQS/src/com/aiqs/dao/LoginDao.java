package com.aiqs.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.aiqs.bean.LoginBean;
import com.aiqs.util.DBConnection;
import com.aiqs.bean.BeanFactory;

public class LoginDao {

	static private String UserTable = "aiqs_login_tb";

	final private static int colUseridIndex = 1;
	final private static int colPasswordIndex = 2;
	final private static int colLoginStatusIndex = 3;
	final private static int colUserTypeIndex = 4;

	final private static String InsertQuery = "INSERT INTO " + UserTable
			+ " VALUES(?, ?, ?, ?)";
	final private static String UpdatePassQuery = "UPDATE " + UserTable
			+ " SET password = ? where user_id = ?";
	final private static String UpdateStatusQuery = "UPDATE " + UserTable
			+ " SET loginstatus = ? where user_id = ?";
	final private static String DeleteQuery = "DELETE FROM " + UserTable
			+ " WHERE user_id = ?";
	final private static String SelectUserQuery = "SELECT * FROM " + UserTable
			+ " WHERE user_id = ?";

	public static String save(final LoginBean login) {
		String Response = "error";
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(InsertQuery);
			// login.setUserType("user");
			// modified
			login.setLoginStatus("OFF");
			login.setUserType("user");
			if (login.getUserId() == 1234567890L)
				login.setUserType("admin");
			else
				login.setUserType("user");
			pstmt.setLong(colUseridIndex, login.getUserId());
			pstmt.setString(colPasswordIndex, login.getPassword());
			pstmt.setString(colUserTypeIndex, login.getUserType());
			pstmt.setString(colLoginStatusIndex, login.getLoginStatus());

			// DBConnection.beginTransaction();
			int RowAffect = pstmt.executeUpdate();

			if (RowAffect != 0) {
				Response = "success";
			}
			DBConnection.endTransaction();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}

		return Response;
	}

	public static String updatePassword(final LoginBean login, String cpass) {
		final int updateUseridIndex = 2;
		final int updatePasswordIndex = 1;

		String Response = "error";
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(
					UpdatePassQuery);
			pstmt.setLong(updateUseridIndex, login.getUserId());
			pstmt.setString(updatePasswordIndex, cpass);

			DBConnection.beginTransaction();
			int RowAffect = pstmt.executeUpdate();

			if (RowAffect != 0) {
				Response = "success";
			}
			DBConnection.endTransaction();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}

		return Response;
	}

	public static String updateStatus(final LoginBean login) {
		final int updateUseridIndex = 2;
		final int updateLoginStatusIndex = 1;
		String Response = "error";
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(
					UpdateStatusQuery);
			pstmt.setLong(updateUseridIndex, login.getUserId());

			if (login.getLoginStatus().equals("ON")) {

				pstmt.setString(updateLoginStatusIndex, "OFF");
			} else {
				pstmt.setString(updateLoginStatusIndex, "ON");
			}

			DBConnection.beginTransaction();
			int RowAffect = pstmt.executeUpdate();

			if (RowAffect != 0) {
				Response = "success";
			}
			DBConnection.endTransaction();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}

		return Response;
	}

	public static String delete(final Long userid) {

		final int deleteUserIDIndex = 1;

		String Response = "error";
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(DeleteQuery);
			pstmt.setLong(deleteUserIDIndex, userid);

			DBConnection.beginTransaction();
			int RowAffect = pstmt.executeUpdate();

			if (RowAffect != 0) {
				Response = "success";
			}
			DBConnection.endTransaction();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}

		return Response;
	}

	public static LoginBean findById(Long userid) {

		final int findUserIDIndex = 1;

		LoginBean login = null;
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(
					SelectUserQuery);
			pstmt.setLong(findUserIDIndex, userid);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				login = BeanFactory.getLoginBean();
				login.setUserId(rs.getLong(colUseridIndex));
				login.setPassword(rs.getString(colPasswordIndex));
				login.setUserType(rs.getString(colUserTypeIndex));
				login.setLoginStatus(rs.getString(colLoginStatusIndex));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}
		return login;
	}

}
