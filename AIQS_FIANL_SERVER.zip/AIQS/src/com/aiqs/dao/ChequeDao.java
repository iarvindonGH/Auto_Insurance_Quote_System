package com.aiqs.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.aiqs.bean.BeanFactory;
import com.aiqs.bean.ChequeBean;
import com.aiqs.util.DBConnection;

public class ChequeDao {

	static private String UserTable = "aiqs_cheque_details_tb";

	final private static int colPNIIndex = 1;
	final private static int colQuoteIDIndex = 2;
	final private static int colChequePickUpDateIndex = 3;
	final private static int colPreferredTimeIndex = 4;

	final private static String InsertQuery = "INSERT INTO " + UserTable
			+ " VALUES(?, ?, ?, ?)";
	final private static String SelectUserQuery = "SELECT * FROM " + UserTable
			+ " WHERE quote_id= ?";
	final private static String DeleteQuery = "DELETE FROM " + UserTable
			+ " WHERE pnino = ?";

	public static String save(final ChequeBean cheque) {
		String Response = "error";
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(InsertQuery);

			pstmt.setLong(colPNIIndex, cheque.getPnino());
			pstmt.setLong(colQuoteIDIndex, cheque.getQuoteId());
			pstmt.setDate(colChequePickUpDateIndex, new java.sql.Date(cheque
					.getChequePickUpDate().getTime()));
			pstmt.setString(colPreferredTimeIndex, cheque.getPreferredTime());

			DBConnection.beginTransaction();
			int RowAffect = pstmt.executeUpdate();

			if (RowAffect != 0) {
				Response = "success";
			}
			DBConnection.endTransaction();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}

		return Response;
	}

	public static ChequeBean findById(Long quoteID) {

		final int updateQuoteIDIndex = 1;

		ChequeBean cheque = null;
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(
					SelectUserQuery);
			pstmt.setLong(updateQuoteIDIndex, quoteID);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				cheque = BeanFactory.getChequeBean();
				cheque.setPnino(rs.getLong(colPNIIndex));
				cheque.setQuoteId(rs.getLong(colQuoteIDIndex));
				cheque.setChequePickUpDate(new java.util.Date(rs.getDate(
						colChequePickUpDateIndex).getTime()));
				cheque.setPreferredTime(rs.getString(colPreferredTimeIndex));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}
		return cheque;
	}

	public static String delete(final Long pnino) {

		final int deletePNIIndex = 1;
		String Response = "error";
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(DeleteQuery);
			pstmt.setLong(deletePNIIndex, pnino);

			DBConnection.beginTransaction();
			int RowAffect = pstmt.executeUpdate();

			if (RowAffect != 0) {
				Response = "success";
			}
			DBConnection.endTransaction();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}

		return Response;
	}
}
