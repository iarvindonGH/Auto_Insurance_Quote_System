package com.aiqs.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.aiqs.bean.BeanFactory;
import com.aiqs.bean.QuoteBean;
import com.aiqs.util.DBConnection;

public class QuoteDao {
	static private String UserTable = "aiqs_quote_details_tb";

	final private static int colUserIDIndex = 1;
	final private static int colQuoteIDIndex = 2;
	final private static int colPolicyTypeIndex = 3;
	final private static int colPolicyStartDateIndex = 4;
	final private static int colPreviousPolicyExpiryDateIndex = 5;
	final private static int colVehicleMakeIndex = 6;
	final private static int colVehicleModelIndex = 7;
	final private static int colVehicleNumberIndex = 8;
	final private static int colYearOfManufactureIndex = 9;
	final private static int colDateOfRegistrationIndex = 10;
	final private static int colStateOfRegistrationIndex = 11;
	final private static int colCityOfRegistrationIndex = 12;
	final private static int colFuelTypeIndex = 13;
	final private static int colShowRoomPriceIndex = 14;
	final private static int colDobOfOwnerIndex = 15;
	final private static int colProfessionOfOwnerIndex = 16;
	final private static int colInsuranceProviderIndex = 17;
	final private static int colPremiumAmountIndex = 18;
	final private static int colEngineNumberIndex = 19;
	final private static int colChassisNumberIndex = 20;
	final private static int colPanNumberIndex = 21;
	final private static int colMailingAddressIndex = 22;
	final private static int colPaymentOptionIndex = 23;

	final private static String InsertQuery = "INSERT INTO "
			+ UserTable
			+ " VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	final private static String UpdateQuery = "UPDATE "
			+ UserTable
			+ " SET policytype=?, policystartdate=?, "
			+ "previouspolicyexpirydate = ?, vehiclemake = ?, vehiclemodel= ?, vehiclenumber= ?, yearofmanufacture = ?,"
			+ "dateofregistration = ?, stateofregistration= ?, cityofregistration = ?, fueltype = ?, showroomprice = ?,"
			+ "dobofowner = ?, professionofowner = ?, insuranceprovider = ?, premiumamount = ?, "
			+ "enginenumber = ?, chassisnumber = ?, pannumber = ?, mailingaddress = ?, paymentoption = ?"
			+ "where user_id = ? and quote_id = ?";
	final private static String DeleteQuery = "DELETE FROM " + UserTable
			+ " WHERE quote_id = ?";
	final private static String SelectUserQuery = "SELECT * FROM " + UserTable
			+ " WHERE quote_id = ?";
	final private static String SelectAllUserQuery = "SELECT * FROM "
			+ UserTable;
	final private static String SelectChassisQuery = "SELECT * FROM "
			+ UserTable + " WHERE chassisnumber = ?";
	final private static String SelectEngineQuery = "SELECT * FROM "
			+ UserTable + " WHERE enginenumber = ?";
	final private static String SelectQuotesQuery = "SELECT * FROM "
			+ UserTable + " WHERE user_id = ?";

	public static String update(final QuoteBean quote) {

		final int updateUserIDIndex = 22;
		final int updateQuoteIDIndex = 23;
		final int updatePolicyTypeIndex = 1;
		final int updatePolicyStartDateIndex = 2;
		final int updatePreviousPolicyExpiryDateIndex = 3;
		final int updateVehicleMakeIndex = 4;
		final int updateVehicleModelIndex = 5;
		final int updateVehicleNumberIndex = 6;
		final int updateYearOfManufactureIndex = 7;
		final int updateDateOfRegistrationIndex = 8;
		final int updateStateOfRegistrationIndex = 9;
		final int updateCityOfRegistrationIndex = 10;
		final int updateFuelTypeIndex = 11;
		final int updateShowRoomPriceIndex = 12;
		final int updateDobOfOwnerIndex = 13;
		final int updateProfessionOfOwnerIndex = 14;
		final int updateInsuranceProviderIndex = 15;
		final int updatePremiumAmountIndex = 16;
		final int updateEngineNumberIndex = 17;
		final int updateChassisNumberIndex = 18;
		final int updatePanNumberIndex = 19;
		final int updateMailingAddressIndex = 20;
		final int updatePaymentOptionIndex = 21;

		String Response = "error";
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(UpdateQuery);
			pstmt.setLong(updateUserIDIndex, quote.getUserID());
			pstmt.setLong(updateQuoteIDIndex, quote.getQuoteID());
			pstmt.setString(updatePolicyTypeIndex, quote.getPolicyType());
			pstmt.setDate(updatePolicyStartDateIndex, new java.sql.Date(quote
					.getPolicyStartDate().getTime()));
			if (quote.getPreviousPolicyExpiryDate() == null) {

				pstmt.setDate(updatePreviousPolicyExpiryDateIndex, null);
			} else {
				pstmt.setDate(updatePreviousPolicyExpiryDateIndex,
						new java.sql.Date(quote.getPreviousPolicyExpiryDate()
								.getTime()));
			}
			pstmt.setString(updateVehicleMakeIndex, quote.getVehicleMake());
			pstmt.setString(updateVehicleModelIndex, quote.getVehicleModel());
			pstmt.setString(updateVehicleNumberIndex, quote.getVehicleNumber());
			pstmt.setDate(updateYearOfManufactureIndex, new java.sql.Date(quote
					.getYearOfManufacture().getTime()));
			pstmt.setDate(updateDateOfRegistrationIndex, new java.sql.Date(
					quote.getDateOfRegistration().getTime()));
			pstmt.setString(updateStateOfRegistrationIndex,
					quote.getStateOfRegistration());
			pstmt.setString(updateCityOfRegistrationIndex,
					quote.getCityOfRegistration());
			pstmt.setString(updateFuelTypeIndex, quote.getFuelType());
			pstmt.setLong(updateShowRoomPriceIndex, quote.getShowRoomPrice());
			pstmt.setDate(updateDobOfOwnerIndex, new java.sql.Date(quote
					.getDobOfOwner().getTime()));
			pstmt.setString(updateProfessionOfOwnerIndex,
					quote.getProfessionOfOwner());
			pstmt.setString(updateInsuranceProviderIndex,
					quote.getInsuranceProvider());
			pstmt.setLong(updatePremiumAmountIndex, quote.getPremiumAmount());
			pstmt.setLong(updateEngineNumberIndex, quote.getEngineNumber());
			pstmt.setString(updateChassisNumberIndex, quote.getChassisNumber());
			pstmt.setString(updatePanNumberIndex, quote.getPanNumber());
			pstmt.setString(updateMailingAddressIndex,
					quote.getMailingAddress());
			pstmt.setString(updatePaymentOptionIndex, quote.getPaymentOption());

			DBConnection.beginTransaction();
			int RowAffect = pstmt.executeUpdate();

			if (RowAffect != 0) {
				Response = "success";
			}
			DBConnection.endTransaction();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}

		return Response;
	}

	public static String save(final QuoteBean quote) {
		String Response = "error";
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(InsertQuery);

			pstmt.setLong(colUserIDIndex, quote.getUserID());
			pstmt.setLong(colQuoteIDIndex, quote.getQuoteID());
			pstmt.setString(colPolicyTypeIndex, quote.getPolicyType());
			pstmt.setDate(colPolicyStartDateIndex, new java.sql.Date(quote
					.getPolicyStartDate().getTime()));
			if (quote.getPreviousPolicyExpiryDate() == null) {

				pstmt.setDate(colPreviousPolicyExpiryDateIndex, null);

			} else {
				pstmt.setDate(colPreviousPolicyExpiryDateIndex,
						new java.sql.Date(quote.getPreviousPolicyExpiryDate()
								.getTime()));
			}
			pstmt.setString(colVehicleMakeIndex, quote.getVehicleMake());
			pstmt.setString(colVehicleModelIndex, quote.getVehicleModel());
			pstmt.setString(colVehicleNumberIndex, quote.getVehicleNumber());
			pstmt.setDate(colYearOfManufactureIndex, new java.sql.Date(quote
					.getYearOfManufacture().getTime()));
			pstmt.setDate(colDateOfRegistrationIndex, new java.sql.Date(quote
					.getDateOfRegistration().getTime()));
			pstmt.setString(colStateOfRegistrationIndex,
					quote.getStateOfRegistration());
			pstmt.setString(colCityOfRegistrationIndex,
					quote.getCityOfRegistration());
			pstmt.setString(colFuelTypeIndex, quote.getFuelType());
			pstmt.setLong(colShowRoomPriceIndex, quote.getShowRoomPrice());
			pstmt.setDate(colDobOfOwnerIndex, new java.sql.Date(quote
					.getDobOfOwner().getTime()));
			pstmt.setString(colProfessionOfOwnerIndex,
					quote.getProfessionOfOwner());
			pstmt.setString(colInsuranceProviderIndex,
					quote.getInsuranceProvider());
			pstmt.setLong(colPremiumAmountIndex, quote.getPremiumAmount());
			pstmt.setLong(colEngineNumberIndex, quote.getEngineNumber());
			pstmt.setString(colChassisNumberIndex, quote.getChassisNumber());
			pstmt.setString(colPanNumberIndex, quote.getPanNumber());
			pstmt.setString(colMailingAddressIndex, quote.getMailingAddress());
			pstmt.setString(colPaymentOptionIndex, quote.getPaymentOption());

			DBConnection.beginTransaction();
			int RowAffect = pstmt.executeUpdate();

			if (RowAffect != 0) {
				Response = "success";
			}
			DBConnection.endTransaction();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}

		return Response;
	}

	public static String delete(final Long quoteid) {

		final int deleteQuoteIDIndex = 1;
		String Response = "error";
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(DeleteQuery);
			pstmt.setLong(deleteQuoteIDIndex, quoteid);

			DBConnection.beginTransaction();
			int RowAffect = pstmt.executeUpdate();

			if (RowAffect != 0) {
				Response = "success";
			}
			DBConnection.endTransaction();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}

		return Response;
	}

	public static QuoteBean findById(Long quoteid) {

		final int selectQuoteIDIndex = 1;
		QuoteBean quote = null;
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(
					SelectUserQuery);
			pstmt.setLong(selectQuoteIDIndex, quoteid);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				quote = BeanFactory.getQuoteBean();
				quote.setUserID(rs.getLong(colUserIDIndex));
				quote.setQuoteID(rs.getLong(colQuoteIDIndex));
				quote.setPolicyType(rs.getString(colPolicyTypeIndex));
				if (rs.getDate(colPreviousPolicyExpiryDateIndex) == null) {
					quote.setPreviousPolicyExpiryDate(null);
				} else {
					quote.setPreviousPolicyExpiryDate(new java.util.Date(rs
							.getDate(colPreviousPolicyExpiryDateIndex)
							.getTime()));
				}

				quote.setPolicyStartDate(new java.util.Date(rs.getDate(
						colPolicyStartDateIndex).getTime()));

				quote.setVehicleMake(rs.getString(colVehicleMakeIndex));
				quote.setVehicleModel(rs.getString(colVehicleModelIndex));
				quote.setVehicleNumber(rs.getString(colVehicleNumberIndex));
				quote.setYearOfManufacture(new java.util.Date(rs.getDate(
						colYearOfManufactureIndex).getTime()));
				quote.setDateOfRegistration(new java.util.Date(rs.getDate(
						colDateOfRegistrationIndex).getTime()));
				quote.setStateOfRegistration(rs
						.getString(colStateOfRegistrationIndex));
				quote.setCityOfRegistration(rs
						.getString(colCityOfRegistrationIndex));
				quote.setFuelType(rs.getString(colFuelTypeIndex));
				quote.setShowRoomPrice(rs.getLong(colShowRoomPriceIndex));
				quote.setDobOfOwner(new java.util.Date(rs.getDate(
						colDobOfOwnerIndex).getTime()));
				quote.setProfessionOfOwner(rs
						.getString(colProfessionOfOwnerIndex));
				quote.setInsuranceProvider(rs
						.getString(colInsuranceProviderIndex));
				quote.setPremiumAmount(rs.getLong(colPremiumAmountIndex));
				quote.setEngineNumber(rs.getLong(colEngineNumberIndex));
				quote.setChassisNumber(rs.getString(colChassisNumberIndex));
				quote.setPanNumber(rs.getString(colPanNumberIndex));
				quote.setMailingAddress(rs.getString(colMailingAddressIndex));
				quote.setPaymentOption(rs.getString(colPaymentOptionIndex));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}
		return quote;
	}

	public static ArrayList<QuoteBean> findAll() {

		QuoteBean quote = null;
		ArrayList<QuoteBean> quoteList = null;
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(
					SelectAllUserQuery);

			ResultSet rs = pstmt.executeQuery();
			quoteList = new ArrayList<QuoteBean>();
			while (rs.next()) {
				quote = BeanFactory.getQuoteBean();
				quote.setUserID(rs.getLong(colUserIDIndex));
				quote.setQuoteID(rs.getLong(colQuoteIDIndex));
				quote.setPolicyType(rs.getString(colPolicyTypeIndex));
				quote.setPolicyStartDate(new java.util.Date(rs.getDate(
						colPolicyStartDateIndex).getTime()));
				if (rs.getDate(colPreviousPolicyExpiryDateIndex) == null) {
					quote.setPreviousPolicyExpiryDate(null);
				} else {
					quote.setPreviousPolicyExpiryDate(new java.util.Date(rs
							.getDate(colPreviousPolicyExpiryDateIndex)
							.getTime()));
				}
				quote.setVehicleMake(rs.getString(colVehicleMakeIndex));
				quote.setVehicleModel(rs.getString(colVehicleModelIndex));
				quote.setVehicleNumber(rs.getString(colVehicleNumberIndex));
				quote.setYearOfManufacture(new java.util.Date(rs.getDate(
						colYearOfManufactureIndex).getTime()));
				quote.setDateOfRegistration(new java.util.Date(rs.getDate(
						colDateOfRegistrationIndex).getTime()));
				quote.setStateOfRegistration(rs
						.getString(colStateOfRegistrationIndex));
				quote.setCityOfRegistration(rs
						.getString(colCityOfRegistrationIndex));
				quote.setFuelType(rs.getString(colFuelTypeIndex));
				quote.setShowRoomPrice(rs.getLong(colShowRoomPriceIndex));
				quote.setDobOfOwner(new java.util.Date(rs.getDate(
						colDobOfOwnerIndex).getTime()));
				quote.setProfessionOfOwner(rs
						.getString(colProfessionOfOwnerIndex));
				quote.setInsuranceProvider(rs
						.getString(colInsuranceProviderIndex));
				quote.setPremiumAmount(rs.getLong(colPremiumAmountIndex));
				quote.setEngineNumber(rs.getLong(colEngineNumberIndex));
				quote.setChassisNumber(rs.getString(colChassisNumberIndex));
				quote.setPanNumber(rs.getString(colPanNumberIndex));
				quote.setMailingAddress(rs.getString(colMailingAddressIndex));
				quote.setPaymentOption(rs.getString(colPaymentOptionIndex));

				quoteList.add(quote);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}
		return quoteList;
	}

	public static boolean findByChassisNo(String chassisNo) {

		final int selectChassisNoIndex = 1;
		boolean key = true;
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(
					SelectChassisQuery);
			pstmt.setString(selectChassisNoIndex, chassisNo);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				key = false;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}
		return key;
	}

	public static boolean findByEngineNo(Long engineNo) {

		final int selectEngineNoIndex = 1;
		boolean key = true;
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(
					SelectEngineQuery);
			pstmt.setLong(selectEngineNoIndex, engineNo);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				key = false;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}
		return key;
	}

	public static ArrayList<QuoteBean> findAllUserQuotes(Long userID) {

		final int selectUserIDIndex = 1;
		QuoteBean quote = null;
		ArrayList<QuoteBean> quoteList = null;
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(
					SelectQuotesQuery);

			pstmt.setLong(selectUserIDIndex, userID);
			ResultSet rs = pstmt.executeQuery();
			quoteList = new ArrayList<QuoteBean>();
			while (rs.next()) {
				quote = BeanFactory.getQuoteBean();
				quote.setUserID(rs.getLong(colUserIDIndex));
				quote.setQuoteID(rs.getLong(colQuoteIDIndex));
				quote.setPolicyType(rs.getString(colPolicyTypeIndex));
				quote.setPolicyStartDate(new java.util.Date(rs.getDate(
						colPolicyStartDateIndex).getTime()));
				if (rs.getDate(colPreviousPolicyExpiryDateIndex) == null) {
					quote.setPreviousPolicyExpiryDate(null);
				} else {
					quote.setPreviousPolicyExpiryDate(new java.util.Date(rs
							.getDate(colPreviousPolicyExpiryDateIndex)
							.getTime()));
				}
				quote.setVehicleMake(rs.getString(colVehicleMakeIndex));
				quote.setVehicleModel(rs.getString(colVehicleModelIndex));
				quote.setVehicleNumber(rs.getString(colVehicleNumberIndex));
				quote.setYearOfManufacture(new java.util.Date(rs.getDate(
						colYearOfManufactureIndex).getTime()));
				quote.setDateOfRegistration(new java.util.Date(rs.getDate(
						colDateOfRegistrationIndex).getTime()));
				quote.setStateOfRegistration(rs
						.getString(colStateOfRegistrationIndex));
				quote.setCityOfRegistration(rs
						.getString(colCityOfRegistrationIndex));
				quote.setFuelType(rs.getString(colFuelTypeIndex));
				quote.setShowRoomPrice(rs.getLong(colShowRoomPriceIndex));
				quote.setDobOfOwner(new java.util.Date(rs.getDate(
						colDobOfOwnerIndex).getTime()));
				quote.setProfessionOfOwner(rs
						.getString(colProfessionOfOwnerIndex));
				quote.setInsuranceProvider(rs
						.getString(colInsuranceProviderIndex));
				quote.setPremiumAmount(rs.getLong(colPremiumAmountIndex));
				quote.setEngineNumber(rs.getLong(colEngineNumberIndex));
				quote.setChassisNumber(rs.getString(colChassisNumberIndex));
				quote.setPanNumber(rs.getString(colPanNumberIndex));
				quote.setMailingAddress(rs.getString(colMailingAddressIndex));
				quote.setPaymentOption(rs.getString(colPaymentOptionIndex));

				quoteList.add(quote);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}

		return quoteList;
	}

}
