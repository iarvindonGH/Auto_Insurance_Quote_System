package com.aiqs.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.aiqs.bean.BeanFactory;
import com.aiqs.bean.DriverBean;
import com.aiqs.util.DBConnection;

public class DriverDao {
	static private String UserTable = "aiqs_driver_details_tb";

	final private static int colDriverIDIndex = 1;
	final private static int colFirstNameIndex = 2;
	final private static int colLastNameIndex = 3;
	final private static int colAgeIndex = 4;
	final private static int colGenderIndex = 5;
	final private static int colAddressIndex = 6;
	final private static int colPhoneNoIndex = 7;
	final private static int colEmailIndex = 8;
	final private static int colQuoteIDIndex = 9;

	final private static String InsertQuery = "INSERT INTO " + UserTable
			+ " VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";

	final private static String UpdateQuery = "UPDATE " + UserTable
			+ " SET firstname=?, lastname=?,"
			+ "age = ?, gender = ?, address= ?, phoneno= ?, email = ?"
			+ "where driver_id = ? and quote_id = ?";

	final private static String DeleteQuery = "DELETE FROM " + UserTable
			+ " WHERE driver_id = ?";
	final private static String SelectAllUserQuery = "SELECT * FROM "
			+ UserTable + " WHERE quote_id= ?";
	final private static String CountQuery = "SELECT COUNT(*) FROM "
			+ UserTable + " where quote_id = ?";
	final private static String SelectQuery = "SELECT * FROM " + UserTable
			+ " WHERE driver_id = ?";
	final private static String SelectAllQuery = "SELECT * FROM " + UserTable
			+ " WHERE quote_id= ?";

	public static String save(final DriverBean driver) {
		String Response = "error";
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(InsertQuery);
			pstmt.setLong(colQuoteIDIndex, driver.getQuoteID());
			pstmt.setLong(colDriverIDIndex, driver.getDriverID());
			pstmt.setString(colFirstNameIndex, driver.getFirstName());
			pstmt.setString(colLastNameIndex, driver.getLastName());
			pstmt.setInt(colAgeIndex, driver.getAge());
			pstmt.setString(colGenderIndex, driver.getGender());
			pstmt.setString(colAddressIndex, driver.getAddress());
			pstmt.setLong(colPhoneNoIndex, driver.getPhoneNo());
			pstmt.setString(colEmailIndex, driver.getEmail());
			// pstmt.setLong(colPNIIndex,driver.getPnino());

			DBConnection.beginTransaction();
			int RowAffect = pstmt.executeUpdate();

			if (RowAffect != 0) {
				Response = "success";
			}
			DBConnection.endTransaction();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}

		return Response;
	}

	public static String update(final DriverBean driver) {

		// final int updatePNIIndex = 10;
		final int updateDriverIDIndex = 8;
		final int updateFirstNameIndex = 1;
		final int updateLastNameIndex = 2;
		final int updateAgeIndex = 3;
		final int updateGenderIndex = 4;
		final int updateAddressIndex = 5;
		final int updatePhoneNoIndex = 6;
		final int updateEmailIndex = 7;
		final int updateQuoteIDIndex = 9;

		String Response = "error";
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(UpdateQuery);
			// pstmt.setLong(updatePNIIndex,driver.getPnino());
			pstmt.setLong(updateQuoteIDIndex, driver.getQuoteID());
			pstmt.setLong(updateDriverIDIndex, driver.getDriverID());
			pstmt.setString(updateFirstNameIndex, driver.getFirstName());
			pstmt.setString(updateLastNameIndex, driver.getLastName());
			pstmt.setInt(updateAgeIndex, driver.getAge());
			pstmt.setString(updateGenderIndex, driver.getGender());
			pstmt.setString(updateAddressIndex, driver.getAddress());
			pstmt.setLong(updatePhoneNoIndex, driver.getPhoneNo());
			pstmt.setString(updateEmailIndex, driver.getEmail());
			System.out.println("before+ RowAffect");

			DBConnection.beginTransaction();
			int RowAffect = pstmt.executeUpdate();
			if (RowAffect != 0) {
				Response = "success";
			}
			DBConnection.endTransaction();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}

		return Response;
	}

	public static String delete(final Long driverid) {

		final int deleteDriverIDIndex = 1;
		String Response = "error";
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(DeleteQuery);
			pstmt.setLong(deleteDriverIDIndex, driverid);

			DBConnection.beginTransaction();
			int RowAffect = pstmt.executeUpdate();

			if (RowAffect != 0) {
				Response = "success";
			}
			DBConnection.endTransaction();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}

		return Response;
	}

	public static ArrayList<DriverBean> findAll(Long quoteid) {

		DriverBean driver = null;
		ArrayList<DriverBean> driverList = null;
		PreparedStatement pstmt = null;
		final int selectDriverIDIndex = 1;
		try {
			pstmt = DBConnection.getConnection().prepareStatement(
					SelectAllUserQuery);

			System.out.println("In dao :" + quoteid);

			pstmt.setLong(selectDriverIDIndex, quoteid);
			ResultSet rs = pstmt.executeQuery();
			driverList = new ArrayList<DriverBean>();
			while (rs.next()) {
				driver = BeanFactory.getDriverBean();

				driver.setAddress(rs.getString(colAddressIndex));
				driver.setAge(rs.getInt(colAgeIndex));
				driver.setDriverID(rs.getLong(colDriverIDIndex));
				driver.setEmail(rs.getString(colEmailIndex));
				driver.setFirstName(rs.getString(colFirstNameIndex));
				driver.setLastName(rs.getString(colLastNameIndex));
				driver.setGender(rs.getString(colGenderIndex));
				driver.setPhoneNo(rs.getLong(colPhoneNoIndex));
				// driver.setPnino(rs.getLong(colPNIIndex));
				driver.setQuoteID(rs.getLong(colQuoteIDIndex));

				driverList.add(driver);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}
		return driverList;
	}

	public static int countDriver(Long quoteid) {

		int check = 0;
		final int countQuoteIDIndex = 1;
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(CountQuery);
			pstmt.setLong(countQuoteIDIndex, quoteid);

			DBConnection.beginTransaction();
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {

				check = rs.getInt(1);
			}
			DBConnection.endTransaction();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}

		return check;
	}

	public static DriverBean findById(Long driverid) {

		final int selectDriverIDIndex = 1;
		DriverBean driver = null;
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(SelectQuery);
			pstmt.setLong(selectDriverIDIndex, driverid);

			DBConnection.beginTransaction();
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {

				driver = BeanFactory.getDriverBean();

				driver.setAddress(rs.getString(colAddressIndex));
				driver.setAge(rs.getInt(colAgeIndex));
				driver.setDriverID(rs.getLong(colDriverIDIndex));
				driver.setEmail(rs.getString(colEmailIndex));
				driver.setFirstName(rs.getString(colFirstNameIndex));
				driver.setLastName(rs.getString(colLastNameIndex));
				driver.setGender(rs.getString(colGenderIndex));
				driver.setPhoneNo(rs.getLong(colPhoneNoIndex));
				driver.setQuoteID(rs.getLong(colQuoteIDIndex));

			}

			DBConnection.endTransaction();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}
		return driver;
	}

	public static Long findById1(Long quoteid) {

		final int selectDriverIDIndex = 1;
		Long driver = 0L;
		PreparedStatement pstmt = null;

		try {
			pstmt = DBConnection.getConnection().prepareStatement(
					SelectAllQuery);
			pstmt.setLong(selectDriverIDIndex, quoteid);

			DBConnection.beginTransaction();
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				return rs.getLong(colDriverIDIndex);
			}

			DBConnection.endTransaction();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			DBConnection.rollbackTransaction();

		} finally {
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeConnection();
		}
		return driver;
	}

}
