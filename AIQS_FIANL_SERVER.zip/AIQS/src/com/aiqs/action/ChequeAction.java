package com.aiqs.action;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.aiqs.bean.ChequeBean;
import com.aiqs.bean.QuoteBean;
import com.aiqs.dao.DriverDao;
import com.aiqs.domain.RegUser;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;

public class ChequeAction extends ActionSupport implements ServletRequestAware,
		Preparable {

	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	// declaring variables for fetching cheque pick up data
	HttpServletRequest request;
	HttpSession session;

	public QuoteBean getQuote() {
		return quote;
	}

	public void setQuote(QuoteBean quote) {
		this.quote = quote;
	}

	public ChequeBean getCheque() {
		return cheque;
	}

	public void setCheque(ChequeBean cheque) {
		this.cheque = cheque;
	}

	QuoteBean quote;
	ChequeBean cheque;

	@Override
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.request = request;
	}

	@Override
	public void validate() {

		if (cheque.getChequePickUpDate() == null
				|| cheque.getChequePickUpDate().compareTo(new Date()) <= 0) {
			addFieldError("cheque.chequePickUpDate", "INVALID DATE ");

		}
		super.validate();
	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		session = request.getSession(false);
		quote = ((QuoteBean) session.getAttribute("gate"));
		if (quote != null) {
			Long userID = quote.getUserID();
			RegUser ruser = new RegUser();
			Long qid = quote.getQuoteID();
			cheque.setQuoteId(qid);
			String r = ruser.paymentCheque(cheque, userID, quote);

			if ("success".equals(r)) {

				session.setAttribute("cc", cheque);
				Long did = DriverDao.findById1(qid);
				session.setAttribute("drid", did);
				return "success";
			} else {
				return "input";// remains on the same page
			}
		} else
			return "invalid";
	}

	@Override
	public void prepare() throws Exception {
		cheque = new ChequeBean();

	}

}
