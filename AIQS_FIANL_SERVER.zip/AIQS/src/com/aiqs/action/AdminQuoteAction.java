package com.aiqs.action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.aiqs.bean.BeanFactory;
import com.aiqs.bean.LoginBean;
import com.aiqs.bean.QuoteBean;
import com.aiqs.domain.Admin;
import com.aiqs.domain.UserFactory;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;

public class AdminQuoteAction extends ActionSupport implements
		ServletRequestAware, Preparable {

	private static final long serialVersionUID = 1L;
	private HttpServletRequest request;
	HttpSession session;
	private Long quoteID;
	LoginBean login;
	QuoteBean quote;
	

	public QuoteBean getQuote() {
		return quote;
	}

	public void setQuote(QuoteBean quote) {
		this.quote = quote;
	}

	public LoginBean getLogin() {
		return login;
	}

	public void setLogin(LoginBean login) {
		this.login = login;
	}

	public Long getQuoteID() {
		return quoteID;
	}

	public void setQuoteID(Long quoteID) {
		this.quoteID = quoteID;
	}

	@Override
	public void prepare() throws Exception {
		quote = BeanFactory.getQuoteBean();

	}
	
	@Override
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.request = request;
	}

	public String getQuoteTable() {
		session = request.getSession(false);
		login = (LoginBean) session.getAttribute("aiqs");

		if (login != null) {
			Admin admin = UserFactory.createAdmin();

			ArrayList<QuoteBean> quotes = admin.adminFindAll();
			if (quotes != null) {

				request.setAttribute("QuoteList", quotes);
				return SUCCESS;
			} else {
				return ERROR;
			}
		} else
			return "invalid";

	}

	public String viewQuote() {

		session = request.getSession(false);
		login = (LoginBean) session.getAttribute("aiqs");

		if (login != null) {
			Admin admin = UserFactory.createAdmin();

			if (quoteID != 0) {
				QuoteBean quote = admin.findQuote(quoteID);
				request.setAttribute("view", quote);
				return SUCCESS;
			} else {
				return INPUT;
			}
		} else
			return "invalid";

	}

	public String deleteQuote() {

		session = request.getSession(false);
		login = (LoginBean) session.getAttribute("aiqs");

		if (login != null) {

			Admin admin = UserFactory.createAdmin();

			String res = null;
			String qid[] = request.getParameterValues("qid");
			for (int i = 0; i < qid.length; i++) {
				if (qid[i] != null) {
					long temp = Long.parseLong(qid[i]);
	
					res = admin.deleteQuote(temp);
				}
				if (!(res.equals("success"))) {
					return INPUT;
				}
			}
			return SUCCESS;

		} else
			return "invalid";
	}

	/**
	 * @return
	 */
	public String premodifyQuote() {
		session = request.getSession(false);
		login = (LoginBean) session.getAttribute("aiqs");

		if (login != null) {

			Admin admin = UserFactory.createAdmin();

			session.setAttribute("quoteIDm", quoteID);
			if (quoteID != 0) {
				quote = admin.findQuote(quoteID);
				request.setAttribute("Quotes", quote);
	
				return "success";
			} else {
	
				return "input";
			}
		} else
			return "invalid";
	}

	public String premodifyQuote1() {
		session = request.getSession(false);
		login = (LoginBean) session.getAttribute("aiqs");

		if (login != null) {
			Admin admin = UserFactory.createAdmin();
			quoteID = (Long) session.getAttribute("quoteIDm");
			if (quoteID != 0) {
				QuoteBean quote = admin.findQuote(quoteID);
				request.setAttribute("viewQuote", quote);
	
				return "success";
			} else {
					return "input";
			}
		} else
			return "invalid";
	}
}
