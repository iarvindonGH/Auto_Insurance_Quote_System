package com.aiqs.action;

import com.opensymphony.xwork2.ActionSupport;

public class TransferRegisterAction extends ActionSupport {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub

		return "success";// redirecting to user registration page

	}

}
