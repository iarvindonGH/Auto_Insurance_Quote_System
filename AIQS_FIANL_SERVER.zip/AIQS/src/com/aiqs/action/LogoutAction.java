package com.aiqs.action;

import com.opensymphony.xwork2.ActionSupport;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.aiqs.bean.LoginBean;
import com.aiqs.domain.Admin;
import com.aiqs.domain.RegUser;
import com.aiqs.domain.UserFactory;

public class LogoutAction extends ActionSupport implements ServletRequestAware {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long userId;
	HttpServletRequest request;

	public void setServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub

		HttpSession session = request.getSession(false);

		LoginBean login = (LoginBean) session.getAttribute("aiqs");
		if (login != null) {
			if (login.getUserType().equals("admin")) {
				Admin admin = UserFactory.createAdmin();
				admin.logout(login);
			} else if (login.getUserType().equals("user")) {
				RegUser ruser = UserFactory.createUser();
				ruser.logout(login);
			}
			// setting status of login user as off
			session.removeAttribute("aiqs");
			session.removeAttribute("newaiqs");
			session.removeAttribute("gate");
			session.removeAttribute("cc");
			session.removeAttribute("drid");
			session.removeAttribute("quoteIDm");
			session.removeAttribute("datt");
			session.removeAttribute("viewDriver");
			session.removeAttribute("aiqss");
			session.removeAttribute("aiqsss");
			session.removeAttribute("driver");
			session.removeAttribute("view");
			session.removeAttribute("q");
			session.removeAttribute("QuoteList");
			session.invalidate();
			return "success";// removing session of user id created
		} else {
			return "success";
		}

	}
}
