package com.aiqs.action;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.aiqs.bean.CreditBean;
import com.aiqs.bean.QuoteBean;
import com.aiqs.dao.DriverDao;
import com.aiqs.domain.RegUser;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;

public class CreditAction extends ActionSupport implements ServletRequestAware,
		Preparable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private HttpServletRequest request;
	CreditBean credit;
	HttpSession session;
	QuoteBean quote;

	public QuoteBean getQuote() {
		return quote;
	}

	public void setQuote(QuoteBean quote) {
		this.quote = quote;
	}

	public CreditBean getCredit() {
		return credit;
	}

	public void setCredit(CreditBean credit) {
		this.credit = credit;
	}

	@Override
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.request = request;
	}

	// all credit card variables
	@Override
	public void validate() {

		try {
			if (credit.getValidityFrom() == null
					|| credit.getValidityFrom().compareTo(new Date()) >= 0) {
				addFieldError("credit.validityFrom",
						"INVALID DATE OR CARD NOT VALID");
			}

			if (credit.getCreditCardNumber() == null
					|| String.valueOf(credit.getCreditCardNumber()).length() != 16
					|| credit.getCreditCardNumber() == 0) {
				addFieldError("credit.creditCardNumber",
						"CREDIT CARD NUMBER MUST BE 16 DIGITS NUMERIC ONLY...!");
			}
			if (credit.getValidityTo() == null
					|| credit.getValidityTo().compareTo(new Date()) <= 0) {

				addFieldError("credit.validityTo",
						"INVALID DATE OR CARD NOT VALID");

			}
		} catch (NumberFormatException n) {
			addFieldError("credit.creditCardNumber",
					"creditcardnumber can only be a number...!");

		}
		super.validate();
	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub

		session = request.getSession(false);

		quote = (QuoteBean) session.getAttribute("gate");
		if (quote != null) {
			Long l = quote.getPremiumAmount();
			Long userID = quote.getUserID();
			credit.setBalance(l);
			Long qid = quote.getQuoteID();
			credit.setQuoteId(qid);
			RegUser ruser = new RegUser();
			String r = ruser.paymentCredit(credit, userID, quote);
			if ("success".equals(r)) {
				session.setAttribute("cc", credit);
				Long did = DriverDao.findById1(qid);
				session.setAttribute("drid", did);
				return "success";// moves to page of generation of user pni no
			} else
				return "input";// error
		} else
			return "invalid";
	}

	@Override
	public void prepare() throws Exception {
		credit = new CreditBean();

	}

}
