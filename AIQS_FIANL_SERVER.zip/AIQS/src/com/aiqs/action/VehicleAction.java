
package com.aiqs.action;

import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import com.aiqs.bean.BeanFactory;
import com.aiqs.bean.QuoteBean;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

public class VehicleAction extends ActionSupport implements ServletRequestAware,Preparable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	QuoteBean quote ;
	private HttpServletRequest request;

	@Override
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.request=request;
	}
	@Override
	public void prepare() throws Exception {
		quote=BeanFactory.getQuoteBean();
	
	}
	
	@Override
	public void validate() {
		// TODO Auto-generated method stub

		if (quote.getPolicyStartDate()== null) {
			
			
			addFieldError("quote.policyStartDate", "policy start date is Required...!");
		}else {
			if(quote.getPolicyStartDate().compareTo(new Date())<0)
				addFieldError("quote.policyStartDate", "Enter valid date...!");
		}
		
		if(quote.getPolicyType().equals("renew")){
			if (quote.getPreviousPolicyExpiryDate() == null) {
			addFieldError("quote.previousPolicyExpiryDate", "previous policy expiry date is Required...!");
			}
			else{
				Calendar curr= Calendar.getInstance(TimeZone.getTimeZone("GMT"));
				Calendar pped = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
				curr.setTime(new Date());
				pped.setTime(quote.getPreviousPolicyExpiryDate());
					// long age = ((curr.getTime()-dob.getTime())% (1000l * 60l * 60l * 24l));
				long dur=0;
				while (pped.before(curr)) {  
					pped.add(Calendar.DAY_OF_MONTH, 1);  
					dur++;  
				} 
				dur/=365;
				if(dur<1)
				{	
					addFieldError("quote.previousPolicyExpiryDate","Enter valid expiry date");
				}
			}
		}
		
		if(quote.getPolicyType().equals("new"))
			if (quote.getPreviousPolicyExpiryDate() != null) {
				addFieldError("quote.previousPolicyExpiryDate", "previous policy expiry date is not Required...!");
			}
		
		if ( quote.getVehicleNumber() == null || quote.getVehicleNumber().length()==0 ) {
			addFieldError("quote.vehicleNumber", "Vehicle Number is Required...!");
		}else {
			try{
				if(quote.getVehicleNumber().length()==10){
				String key1 = quote.getVehicleNumber().substring(0, 2);
				Integer.parseInt(quote.getVehicleNumber().substring(2, 4));
				Integer.parseInt(quote.getVehicleNumber().substring(6, 9));
				}else{
					addFieldError("quote.vehicleNumber", "Enter valid vehicle number");
				}
			}		
			catch(Exception ex){
					addFieldError("quote.vehicleNumber", "Enter valid Vehicle number");
				}
		}
		
		if(quote.getYearOfManufacture()== null || quote.getYearOfManufacture().compareTo(new Date())>=0)
		{
				addFieldError("quote.yearOfManufacture","Invalid Date");
	
		}
		
		if(quote.getDateOfRegistration()== null || quote.getDateOfRegistration().compareTo(quote.getYearOfManufacture())<=0 || quote.getDateOfRegistration().compareTo(new Date())>=0)
		{
			addFieldError("quote.dateOfRegistration","Invalid Date");
	
		}
		
		if(quote.getDobOfOwner()==null)
		{
			addFieldError("quote.dobOfOwner","can not be empty");
		
		}
		else
		{
			Calendar curr= Calendar.getInstance(TimeZone.getTimeZone("GMT"));
			Calendar dob = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
			curr.setTime(new Date());
			dob.setTime(quote.getDobOfOwner());
				// long age = ((curr.getTime()-dob.getTime())% (1000l * 60l * 60l * 24l));
			long age=0;
			while (dob.before(curr)) {  
				dob.add(Calendar.DAY_OF_MONTH, 1);  
				age++;  
			} 
			age/=365;
			if(age<18)
			{
				addFieldError("quote.dobOfOwner","Must be 18 years");
			 
			}
		}
		
		if (quote.getStateOfRegistration()== null||quote.getStateOfRegistration().length()==0) {
			addFieldError("quote.stateOfRegistration", "state of registration is Required...!");
		}
		
		if (quote.getCityOfRegistration()== null||quote.getCityOfRegistration().length()==0) {
			addFieldError("quote.cityOfRegistration", "city of registration is Required...!");
		}
		
		if (quote.getShowRoomPrice()==null || quote.getShowRoomPrice()==0) {
			addFieldError("quote.showRoomPrice", "showroomprice is Required...!");
		}
		
		super.validate();
	}

		
	@Override
	public String execute() throws Exception {
		
       	HttpSession session = request.getSession(false);	
		session.setAttribute("aiqss", quote);
		quote=(QuoteBean)session.getAttribute("aiqss");
		if(quote.getPolicyType().equals("new"))
		{
			
			if(quote.getPreviousPolicyExpiryDate()!=null)
			{
				return "input";
			}
		}
	
		
		
			
		
		Long price = quote.getShowRoomPrice();
		
		Long premium = 4*((80*price)/100)/100L;
		
		quote.setPremiumAmount(premium);
		
		
		
		if(quote!=null)
		{
		return "success";
		}
		else
			return "invalid";
	
	
	}
	public QuoteBean getQuote() {
		return quote;
	}
	public void setQuote(QuoteBean quote) {
		this.quote = quote;
	}
}
