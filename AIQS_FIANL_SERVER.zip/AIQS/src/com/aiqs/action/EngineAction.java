package com.aiqs.action;

import com.aiqs.bean.LoginBean;
import com.aiqs.bean.QuoteBean;
import com.aiqs.domain.RegUser;
import com.aiqs.domain.UserFactory;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

public class EngineAction extends ActionSupport implements ServletRequestAware,
		Preparable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	QuoteBean quote;
	HttpSession session;

	private HttpServletRequest request;

	@Override
	public void setServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	@Override
	public void prepare() throws Exception {
		session = request.getSession(false);
		quote = (QuoteBean) session.getAttribute("aiqsss");

	}

	@Override
	public void validate() {
		// TODO Auto-generated method stub

		if (quote.getEngineNumber() == null
				|| String.valueOf(quote.getEngineNumber()).length() != 10
				|| quote.getEngineNumber() == 0) {
			addFieldError("quote.engineNumber",
					"ENGINE NUMBER MUST BE 10 DIGITS ONLY...!");
		}
		if (quote.getChassisNumber() == null) {
			addFieldError("quote.chassisNumber",
					"chassis number is Required...!");
		}

		if (quote.getChassisNumber() != null) {
			try {
				if (quote.getChassisNumber().length() == 10) {
					String key1 = quote.getChassisNumber().substring(0, 2);
					Integer.parseInt(quote.getChassisNumber().substring(2, 9));
				} else {
					addFieldError("quote.chassisNumber",
							"Enter vaild chassis number");
				}
			}

			catch (Exception ex) {
				addFieldError("quote.chassisNumber",
						"Enter valid Chassis number");
			}

		}
		if (quote.getPanNumber() == null) {
			addFieldError("quote.panNumber", "pan number is Required...!");
		}

		if (quote.getPanNumber() != null) {
			try {
				if (quote.getPanNumber().length() == 10) {
					String key1 = quote.getPanNumber().substring(0, 4);
					int key2 = Integer.parseInt(quote.getPanNumber().substring(
							5, 8));

				} else {
					addFieldError("quote.panNumber", "Enter valid PAN number");
				}
			}

			catch (Exception ex) {
				addFieldError("quote.panNumber", "Enter valid PAN number");
			}
		}
		if (quote.getMailingAddress() == null
				|| quote.getMailingAddress().length() == 0) {

			addFieldError("quote.mailingAddress",
					"Mailing Address is Required...!");
		}
		if (quote.getPaymentOption() == null) {
			addFieldError("quote.paymentOption",
					"Please select a payment option...!");
		}

		super.validate();
	}

	@Override
	public String execute() {
		RegUser ruser = UserFactory.createUser();

		quote = (QuoteBean) session.getAttribute("aiqsss");
		if (quote != null) {
			quote.setUserID(((LoginBean) session.getAttribute("aiqs"))
					.getUserId());
			String r = ruser.buyInsurance(quote);
			if ("success".equals(r)) {
				session.setAttribute("gate", quote);

				return "success";

			} else {
				return "input";

			}
		} else
			return "invalid";

	}

	public QuoteBean getQuote() {
		return quote;
	}

	public void setQuote(QuoteBean quote) {
		this.quote = quote;
	}

}