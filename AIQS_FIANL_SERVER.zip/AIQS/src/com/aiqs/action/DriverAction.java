package com.aiqs.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.aiqs.bean.BeanFactory;
import com.aiqs.bean.DriverBean;
import com.aiqs.domain.RegUser;
import com.aiqs.domain.UserFactory;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;

public class DriverAction extends ActionSupport implements ServletRequestAware,
		Preparable {

	private static final long serialVersionUID = 1L;
	private HttpServletRequest request;
	HttpSession session;
	private Long driverID;
	DriverBean driver;

	@Override
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.request = request;
	}

	public Long getDriverID() {
		return driverID;
	}

	public void setDriverID(Long driverID) {
		this.driverID = driverID;
	}

	public DriverBean getDriver() {
		return driver;
	}

	public void setDriver(DriverBean driver) {
		this.driver = driver;
	}

	public String postmodifyDriver() {
		RegUser user = UserFactory.createUser();

		String response = user.modifyDriver(driver);
		if (response.equals("success"))
			return SUCCESS;
		else
			return INPUT;
	}

	@Override
	public void prepare() throws Exception {
		driver = BeanFactory.getDriverBean();

	}

	public String premodifyDriver() {

		RegUser user = UserFactory.createUser();

		if (driverID != 0) {
			driver = user.findDriver(driverID);
			request.setAttribute("Driver", driver);

			return SUCCESS;
		} else {

			return INPUT;
		}
	}

	public String deleteDriver() {

		RegUser user = UserFactory.createUser();

		String res = null;
		String did[] = request.getParameterValues("did");
		for (int i = 0; i < did.length; i++) {
			if (did[i] != null) {
				long temp = Long.parseLong(did[i]);

				res = user.deleteDriver(temp);
			}
			if (!(res.equals("success"))) {
				return INPUT;
			}
		}
		return SUCCESS;

	}

}
