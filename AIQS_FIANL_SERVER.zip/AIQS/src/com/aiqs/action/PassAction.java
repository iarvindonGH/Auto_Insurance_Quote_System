package com.aiqs.action;

import com.opensymphony.xwork2.ActionSupport;

public class PassAction extends ActionSupport {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub

		return "success";// redirecting to change your password page

	}

}
