package com.aiqs.action;

//import java.rmi.server.UID;
// java.sql.SQLException;
//import java.util.ArrayList;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import com.aiqs.bean.LoginBean;
//import com.aiqs.bean.RegisterBean;
//import com.aiqs.dao.LoginDao;
//import com.aiqs.dao.LogoutDao;
//import com.aiqs.dao.RegisterDao;
//import com.aiqs.domain.LoginClass;
import com.aiqs.domain.SiteUser;

//import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

public class LoginAction extends ActionSupport implements ServletRequestAware,
		Preparable {
	/**
	 * 
	 */
	public LoginBean login;
	HttpServletRequest request;
	Long uid;
	SiteUser user = new SiteUser();

	@Override
	public void prepare() throws Exception {
		// TODO Auto-generated method stub
		login = new LoginBean();
	}

	private static final long serialVersionUID = 1L;

	@Override
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.request = request;

	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub

		String r = user.checkCredential(login);

		HttpSession session = request.getSession(true);

		if (r.equals("admin")) {
			login.setLoginStatus("ON");
			session.setAttribute("aiqs", login);
			uid = login.getUserId();
			session.setAttribute("newaiqs", uid);
			return "admin";
		} else if (r.equals("success")) {
			login.setLoginStatus("ON");
			session.setAttribute("aiqs", login);
			uid = login.getUserId();
			session.setAttribute("newaiqs", uid);
			return "success";
		} else {
			addActionError("Wrong Credentials");
			return "input";
		}

	}

}
