package com.aiqs.action;

import com.aiqs.bean.QuoteBean;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

public class InsuranceAction extends ActionSupport implements
		ServletRequestAware, Preparable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	QuoteBean quote;
	private HttpServletRequest request;
	HttpSession session;

	@Override
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.request = request;
	}

	@Override
	public void prepare() throws Exception {
		session = request.getSession(false);

		quote = (QuoteBean) session.getAttribute("aiqss");
	}

	@Override
	public String execute() throws Exception {
		session.setAttribute("aiqsss", quote);
		quote = (QuoteBean) session.getAttribute("aiqsss");

		if (quote != null) {
			return "success";
		} else {
			return "invalid";
		}
	}

	public QuoteBean getQuote() {
		return quote;
	}

	public void setQuote(QuoteBean quote) {
		this.quote = quote;
	}
}
