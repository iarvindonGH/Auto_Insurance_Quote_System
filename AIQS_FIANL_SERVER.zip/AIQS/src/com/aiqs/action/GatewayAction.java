package com.aiqs.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

//import com.aiqs.bean.LoginBean;
import com.aiqs.bean.QuoteBean;
import com.opensymphony.xwork2.ActionSupport;

public class GatewayAction extends ActionSupport implements ServletRequestAware {
	HttpServletRequest request;
	HttpSession session;
	QuoteBean quote;

	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.request = request;

	}

	/**
		 * 
		 */
	private static final long serialVersionUID = 1L;

	/**
		 * 
		 */

	@Override
	public String execute() {
		// TODO Auto-generated method stub
		session = request.getSession(false);
		// quote=(QuoteBean)session.getAttribute("gate");
		quote = (QuoteBean) session.getAttribute("gate");
		if (quote != null) {

			quote.getPaymentOption();

			if ("cheque".equals(quote.getPaymentOption())) {
				return "cheque";

			} else

				return "credit";//
		} else
			return "invalid";
	}
}
