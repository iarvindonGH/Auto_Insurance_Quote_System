package com.aiqs.action;

//import java.sql.SQLException;
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
//import com.opensymphony.xwork2.validator.annotations.Validations;
//import com.aiqs.action.LoginAction;
import com.aiqs.bean.BeanFactory;
import com.aiqs.bean.LoginBean;
import com.aiqs.bean.UserBean;
//import com.aiqs.bean.RegisterBean;
//import com.aiqs.dao.RegisterDao;
import com.aiqs.domain.SiteUser;

public class RegisterAction extends ActionSupport implements Preparable {

	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	public UserBean user;
	public LoginBean lb;

	@Override
	public void prepare() throws Exception {

		// TODO Auto-generated method stub
		user = BeanFactory.getUserBean();

	}

	@Override
	public String execute() throws Exception {
		String type = ERROR;
		try {
			user.setAddress(user.getStreet() + user.getState().trim()
					+ user.getDistrict() + user.getPin());
			// TODO Auto-generated method stub
			SiteUser su = new SiteUser();
			if (su.register(user).equals("success"))
				type = "success";
			else {
				addActionError("Registration Failed!");
				type = "input";
			}
		} catch (NumberFormatException e) {
			addActionError("invalis should be in string");
		}
		return type;
	}

	public UserBean getUser() {
		return user;
	}

	public void setUser(UserBean user) {
		this.user = user;
	}

	public LoginBean getLb() {
		return lb;
	}

	public void setLb(LoginBean lb) {
		this.lb = lb;
	}

}
