package com.aiqs.action;

import com.opensymphony.xwork2.ActionSupport;

public class BackAAction extends ActionSupport {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */

	@Override
	public String execute() {
		// TODO Auto-generated method stub

		return "success";// redirecting to homepage

	}

}
