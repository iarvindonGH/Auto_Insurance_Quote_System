package com.aiqs.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.aiqs.bean.DriverBean;
import com.aiqs.bean.LoginBean;
import com.aiqs.domain.RegUser;
import com.aiqs.domain.UserFactory;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.validator.annotations.Validations;

public class UpdateDriverAction extends ActionSupport implements
		ServletRequestAware {

	private static final long serialVersionUID = 1L;
	private HttpServletRequest request;
	HttpSession session;
	DriverBean driver;
	LoginBean login;

	public LoginBean getLogin() {
		return login;
	}

	public void setLogin(LoginBean login) {
		this.login = login;
	}

	@Override
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.request = request;
	}

	@Validations
	public String postmodifyDriver() {
		session = request.getSession(false);
		login = (LoginBean) session.getAttribute("aiqs");

		if (login != null) {
			RegUser user = UserFactory.createUser();

			String response = user.modifyDriver(driver);
			if (response.equals("success"))
				return SUCCESS;
			else
				return INPUT;
		} else
			return "invalid";
	}

	public DriverBean getDriver() {
		return driver;
	}

	public void setDriver(DriverBean driver) {
		this.driver = driver;
	}

}
