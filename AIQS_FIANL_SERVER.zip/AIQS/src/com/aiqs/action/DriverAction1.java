package com.aiqs.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.aiqs.bean.QuoteBean;
import com.aiqs.domain.RegUser;
import com.opensymphony.xwork2.ActionSupport;

public class DriverAction1 extends ActionSupport implements ServletRequestAware {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		// TODO Auto-generated method stub

	}

	HttpSession session;
	QuoteBean quote;

	public QuoteBean getQuote() {
		return quote;
	}

	public void setQuote(QuoteBean quote) {
		this.quote = quote;
	}

	@Override
	public String execute() {
		// TODO Auto-generated method stub
		quote = (QuoteBean) session.getAttribute("gate");
		Long qid = quote.getUserID();

		RegUser ruser = new RegUser();
		String r = ruser.checkDriver(qid);
		if ("success".equals(r))
			return "success";// where user can view all his drivers
		else
			return "input";

	}

}
