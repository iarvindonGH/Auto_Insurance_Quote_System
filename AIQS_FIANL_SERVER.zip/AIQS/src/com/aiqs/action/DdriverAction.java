package com.aiqs.action;

//import java.sql.SQLException;
//import java.util.Calendar;
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

//import org.apache.naming.factory.BeanFactory;
import org.apache.struts2.interceptor.ServletRequestAware;

import com.aiqs.bean.DriverBean;
import com.aiqs.bean.LoginBean;
//import com.aiqs.bean.QuoteBean;
import com.aiqs.domain.RegUser;
import com.aiqs.domain.UserFactory;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;

public class DdriverAction extends ActionSupport implements
		ServletRequestAware, Preparable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	HttpServletRequest request;
	HttpSession session;
	DriverBean driver;
	private Long quoteID;
	LoginBean login;
	Long qid;

	public LoginBean getLogin() {
		return login;
	}

	public void setLogin(LoginBean login) {
		this.login = login;
	}

	public Long getQuoteID() {
		return quoteID;
	}

	public void setQuoteID(Long quoteID) {
		this.quoteID = quoteID;
	}

	public DriverBean getDriver() {
		return driver;
	}

	public void setDriver(DriverBean driver) {
		this.driver = driver;
	}

	public void setServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	@Override
	public String execute() throws Exception {

		session = request.getSession(false);
		login = (LoginBean) session.getAttribute("aiqs");

		if (login != null) {
			// driver.setAddress(driver.getStreet()+driver.getState()+driver.getDistrict()+driver.getPin());

			RegUser ruser = UserFactory.createUser();

			// String d=ruser.checkDriver();

			qid = (Long) session.getAttribute("q");
			driver.setQuoteID(qid);

			String r1 = ruser.checkDriver(qid);
			if (r1.equals("success")) {
				String r = ruser.addDriver(driver);

				if ("success".equals(r)) {
					session.setAttribute("datt", driver);
					return "success";

				} else
					return "input";
			} else
				return "fail";
		}
		return "invalid";

	}

	@Override
	public void prepare() throws Exception {
		driver = new DriverBean();
	}

}
