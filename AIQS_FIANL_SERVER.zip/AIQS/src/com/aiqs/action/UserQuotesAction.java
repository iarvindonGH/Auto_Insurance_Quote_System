package com.aiqs.action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.aiqs.bean.DriverBean;
import com.aiqs.bean.LoginBean;
import com.aiqs.bean.QuoteBean;
import com.aiqs.domain.RegUser;
import com.aiqs.domain.UserFactory;
import com.opensymphony.xwork2.ActionSupport;

public class UserQuotesAction extends ActionSupport implements
		ServletRequestAware {

	private static final long serialVersionUID = 1L;
	QuoteBean quote;
	private HttpServletRequest request;
	HttpSession session;
	private Long quoteID;
	LoginBean login;

	public LoginBean getLogin() {
		return login;
	}

	public void setLogin(LoginBean login) {
		this.login = login;
	}

	@Override
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.request = request;
	}

	public QuoteBean getQuote() {
		return quote;
	}

	public void setQuote(QuoteBean quote) {
		this.quote = quote;
	}

	public Long getQuoteID() {
		return quoteID;
	}

	public void setQuoteID(Long quoteID) {
		this.quoteID = quoteID;
	}

	public String getQuoteTable() {
		session = request.getSession(false);
		login = (LoginBean) session.getAttribute("aiqs");

		if (login != null) {
			RegUser user = UserFactory.createUser();
			session = request.getSession(false);
			login = (LoginBean) session.getAttribute("aiqs");
			Long userID = login.getUserId();

			ArrayList<QuoteBean> quotes = user.userFindAllQuotes(userID);
			if (quotes != null) {
				request.setAttribute("QuoteList", quotes);
				return SUCCESS;
			} else {
				return ERROR;
			}
		} else
			return "invalid";

	}

	public String viewQuote() {
		session = request.getSession(false);
		login = (LoginBean) session.getAttribute("aiqs");

		if (login != null) {
			RegUser user = UserFactory.createUser();

			if (quoteID != 0) {
				QuoteBean quote = user.findQuote(quoteID);
				request.setAttribute("view", quote);
				return SUCCESS;
			} else {
				return INPUT;
			}
		} else
			return "invalid";

	}

	public String driverview() {
		session = request.getSession(false);
		login = (LoginBean) session.getAttribute("aiqs");

		if (login != null) {
			RegUser user = UserFactory.createUser();

			if (quoteID != 0) {
				ArrayList<DriverBean> drivers = user.userFindAll(quoteID);

				session.setAttribute("q", quoteID);
				request.setAttribute("driver", drivers);
				return SUCCESS;
			} else {
				return INPUT;
			}

		} else
			return "invalid";

	}

	public String driverview1() {
		session = request.getSession(false);
		login = (LoginBean) session.getAttribute("aiqs");

		if (login != null) {
			RegUser user = UserFactory.createUser();
			session = request.getSession(false);
			quoteID = (Long) session.getAttribute("q");
			ArrayList<DriverBean> drivers = user.userFindAll(quoteID);
			request.setAttribute("driver", drivers);
			if (drivers != null)
				return SUCCESS;
			else
				return INPUT;

		} else
			return "invalid";

	}

}
