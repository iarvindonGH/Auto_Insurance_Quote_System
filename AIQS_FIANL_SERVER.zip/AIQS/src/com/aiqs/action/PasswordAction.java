package com.aiqs.action;

//import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.aiqs.bean.LoginBean;
import com.aiqs.domain.Admin;
import com.aiqs.domain.RegUser;
import com.aiqs.domain.UserFactory;
import com.opensymphony.xwork2.ActionSupport;

import org.apache.struts2.interceptor.ServletRequestAware;

public class PasswordAction extends ActionSupport implements
		ServletRequestAware {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String r;
	HttpServletRequest request;

	public String op;
	public String cp;

	public String getOp() {
		return op;
	}

	public void setOp(String op) {
		this.op = op;
	}

	public String np;

	public String getNp() {
		return np;
	}

	public void setNp(String np) {
		this.np = np;
	}

	public void setServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	@Override
	public void validate() {
		// TODO Auto-generated method stub

		if (op == null || op.length() == 0) {
			addFieldError("op", "password is Required...!");
		}

		if (np == null || np.length() == 0) {
			addFieldError("np", " new password is Required...!");
		}

		if (cp == null || cp.length() == 0) {
			addFieldError("cp", "confirm password is Required...!");
		}
		if (np.length() < 6 || np.length() > 20) {
			addFieldError("np",
					"Minimum password length should be between 6 and 20");
		}
		if (cp.equals(np) == false) {
			addFieldError("cp", "both new password should be equal...!");
		}

		super.validate();

	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub

		HttpSession session = request.getSession(false);
		LoginBean login = (LoginBean) session.getAttribute("aiqs");
		if (login != null) {
			String cpass = this.getNp();
			String opass = this.getOp();

			String old = login.getPassword();

			if (old.equals(opass)) {

				if (login.getUserType().equals("admin")) {

					Admin admin = UserFactory.createAdmin();
					r = admin.changePassword(login, cpass);
				} else {
					RegUser ruser = UserFactory.createUser();
					r = ruser.changePassword(login, cpass);

				}
			} else {
				addActionError("Old Password doesnot match!");
				return "input";

			}
			// Boolean b=ob.updatePassword(this);
			// this.setUsertype(ob.getType(this));

			if (r == "success") {
				if (login.getUserType().equalsIgnoreCase("admin")) {
					login.setPassword(np);
					return "admin";
				}// to admin homepage
				else {
					login.setPassword(np);
					return "success";// to user homepage
				}
			}

			else
				return "input";// error
		} else {

			return "invalid";

		}

	}

	public String getCp() {
		return cp;
	}

	public void setCp(String cp) {
		this.cp = cp;
	}

}
