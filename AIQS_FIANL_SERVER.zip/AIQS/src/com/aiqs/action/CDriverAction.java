package com.aiqs.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.aiqs.bean.LoginBean;
import com.aiqs.bean.QuoteBean;
import com.aiqs.domain.RegUser;
import com.opensymphony.xwork2.ActionSupport;

public class CDriverAction extends ActionSupport implements ServletRequestAware {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	HttpSession session;
	QuoteBean quote;
	private HttpServletRequest request;
	private Long quoteID1;
	LoginBean login;

	public LoginBean getLogin() {
		return login;
	}

	public void setLogin(LoginBean login) {
		this.login = login;
	}

	public QuoteBean getQuote() {
		return quote;
	}

	public void setQuote(QuoteBean quote) {
		this.quote = quote;
	}

	public Long getQuoteID1() {
		return quoteID1;
	}

	public void setQuoteID1(Long quoteID1) {
		this.quoteID1 = quoteID1;
	}

	@Override
	public String execute() {

		RegUser ruser = new RegUser();

		session = request.getSession(false);
		quoteID1 = (Long) session.getAttribute("q");

		String r = ruser.checkDriver(quoteID1);
		if ("success".equals(r))
			return "success";// where user can view all his drivers
		else
			return "input";

	}

	@Override
	public void setServletRequest(HttpServletRequest request) {

		this.request = request;

	}

}
