package com.aiqs.action;

import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;
//import org.apache.struts2.interceptor.validation.SkipValidation;

import com.aiqs.bean.BeanFactory;
//import com.aiqs.bean.DriverBean;
import com.aiqs.bean.LoginBean;
import com.aiqs.bean.QuoteBean;
import com.aiqs.domain.Admin;
//import com.aiqs.domain.RegUser;
import com.aiqs.domain.UserFactory;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import com.opensymphony.xwork2.validator.annotations.Validations;

public class AdminModifyAction extends ActionSupport implements
		ServletRequestAware, Preparable {

	private static final long serialVersionUID = 1L;
	private HttpServletRequest request;
	HttpSession session;
	QuoteBean quote;
	private Long quoteID;
	LoginBean login;

	public LoginBean getLogin() {
		return login;
	}

	public void setLogin(LoginBean login) {
		this.login = login;
	}

	public QuoteBean getQuote() {
		return quote;
	}

	public void setQuote(QuoteBean quote) {
		this.quote = quote;
	}

	public Long getQuoteID() {
		return quoteID;
	}

	public void setQuoteID(Long quoteID) {
		this.quoteID = quoteID;
	}

	@Override
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.request = request;
	}

	@Override
	public void prepare() throws Exception {
		quote = BeanFactory.getQuoteBean();

	}

	@Override
	public void validate() {
		// TODO Auto-generated method stub

		if (quote.getVehicleNumber() == null
				|| quote.getVehicleNumber().length() == 0) {
			addFieldError("quote.vehicleNumber",
					"Vehicle Number is Required...!");
		} else {
			try {
				if (quote.getVehicleNumber().length() == 10) {
					String key1 = quote.getVehicleNumber().substring(0, 2);
					Integer.parseInt(quote.getVehicleNumber().substring(2, 4));
					Integer.parseInt(quote.getVehicleNumber().substring(6, 9));
				} else {
					addFieldError("quote.vehicleNumber",
							"Enter valid vehicle number");
				}
			} catch (Exception ex) {
				addFieldError("quote.vehicleNumber",
						"Enter valid Vehicle number");
			}
		}

		if (quote.getYearOfManufacture() == null
				|| quote.getYearOfManufacture().compareTo(new Date()) >= 0) {

			addFieldError("quote.yearOfManufacture", "Invalid Date");

		}

		if (quote.getDateOfRegistration() == null
				|| quote.getDateOfRegistration().compareTo(
						quote.getYearOfManufacture()) <= 0
				|| quote.getDateOfRegistration().compareTo(new Date()) >= 0) {

			addFieldError("quote.dateOfRegistration", "Invalid Date");

		}

		if (quote.getDobOfOwner() == null) {
			addFieldError("quote.dobOfOwner", "can not be empty");

		} else {
			Calendar curr = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
			Calendar dob = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
			curr.setTime(new Date());
			dob.setTime(quote.getDobOfOwner());

			// long age = ((curr.getTime()-dob.getTime())% (1000l * 60l * 60l *
			// 24l));
			long age = 0;
			while (dob.before(curr)) {
				dob.add(Calendar.DAY_OF_MONTH, 1);
				age++;
			}
			age /= 365;

			if (age < 18) {
				addFieldError("quote.dobOfOwner", "Must be 18 years");

			}
		}

		if (quote.getStateOfRegistration() == null
				|| quote.getStateOfRegistration().length() == 0) {
			addFieldError("quotes.stateOfRegistration",
					"state of registration is Required...!");
		}

		if (quote.getCityOfRegistration() == null
				|| quote.getCityOfRegistration().length() == 0) {
			addFieldError("quote.cityOfRegistration",
					"city of registration is Required...!");
		}

		if (quote.getShowRoomPrice() == null || quote.getShowRoomPrice() == 0) {
			addFieldError("quotes.showRoomPrice",
					"showroomprice is Required...!");
		}
		if (quote.getEngineNumber() == null
				|| String.valueOf(quote.getEngineNumber()).length() != 10
				|| quote.getEngineNumber() == 0) {
			addFieldError("quotes.engineNumber",
					"ENGINE NUMBER MUST BE 10 DIGITS ONLY...!");
		}
		if (quote.getChassisNumber() == null) {
			addFieldError("quote.chassisNumber",
					"chassis number is Required...!");
		}

		if (quote.getChassisNumber() != null) {
			try {
				if (quote.getChassisNumber().length() == 10) {
					String key1 = quote.getChassisNumber().substring(0, 2);
					Integer.parseInt(quote.getChassisNumber().substring(2, 9));
				} else {
					addFieldError("quote.chassisNumber",
							"Enter vaild chassis number");
				}
			}

			catch (Exception ex) {
				addFieldError("quote.chassisNumber",
						"Enter valid Chassis number");
			}

		}
		if (quote.getPanNumber() == null) {
			addFieldError("quote.panNumber", "pan number is Required...!");
		}

		if (quote.getPanNumber() != null) {
			try {
				if (quote.getPanNumber().length() == 10) {
					String key1 = quote.getPanNumber().substring(0, 4);
					int key2 = Integer.parseInt(quote.getPanNumber().substring(
							5, 8));

				} else {
					addFieldError("quote.panNumber", "Enter valid PAN number");
				}
			}

			catch (Exception ex) {
				addFieldError("quote.panNumber", "Enter valid PAN number");
			}
		}
		if (quote.getMailingAddress() == null
				|| quote.getMailingAddress().length() == 0) {

			addFieldError("quote.mailingAddress",
					"Mailing Address is Required...!");
		}
		super.validate();
	}

	@Validations
	public String postmodifyQuote() {

		session = request.getSession(false);
		login = (LoginBean) session.getAttribute("aiqs");

		if (login != null) {
			Admin admin = UserFactory.createAdmin();

			String response = admin.modifyQuote(quote);
			if (response.equals("success"))
				return SUCCESS;
			else
				return INPUT;
		} else
			return "invalid";
	}

}
