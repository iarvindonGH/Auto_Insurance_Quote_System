package com.aiqs.domain;

public abstract class User {

}
