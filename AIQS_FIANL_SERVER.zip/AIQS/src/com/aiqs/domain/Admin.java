package com.aiqs.domain;

import java.util.ArrayList;

import com.aiqs.bean.LoginBean;
import com.aiqs.bean.QuoteBean;
import com.aiqs.dao.LoginDao;
import com.aiqs.dao.QuoteDao;

public class Admin {

	public String deleteQuote(Long quoteID) {

		String check = QuoteDao.delete(quoteID);

		if (check.equals("success")) {
			return "success";
		} else
			return "input";
	}

	public String modifyQuote(QuoteBean quote) {

		String check;
		check = QuoteDao.update(quote);
		if (check.equals("success")) {
			return "success";
		} else
			return "input";
	}

	public QuoteBean findQuote(Long quoteID) {

		QuoteBean quote = QuoteDao.findById(quoteID);
		return quote;

	}

	public ArrayList<QuoteBean> adminFindAll() {

		ArrayList<QuoteBean> AList = new ArrayList<QuoteBean>();
		AList = QuoteDao.findAll();
		return AList;

	}

	public String changePassword(LoginBean login, String cpass) {

		String Response = LoginDao.updatePassword(login, cpass);

		if (Response.equals("success"))
			return "success";
		else
			return "input";
	}

	public String logout(LoginBean login) {

		return (LoginDao.updateStatus(login));

	}
}
