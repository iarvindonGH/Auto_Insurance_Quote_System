package com.aiqs.domain;

import java.util.ArrayList;

import com.aiqs.bean.BeanFactory;
import com.aiqs.bean.ChequeBean;
import com.aiqs.bean.CreditBean;
import com.aiqs.bean.DriverBean;
import com.aiqs.bean.LoginBean;
import com.aiqs.bean.QuoteBean;
import com.aiqs.bean.UserBean;
import com.aiqs.dao.ChequeDao;
import com.aiqs.dao.CreditDao;
import com.aiqs.dao.DriverDao;
import com.aiqs.dao.LoginDao;
import com.aiqs.dao.QuoteDao;
import com.aiqs.dao.UserDao;
import com.aiqs.util.IdGenerator;

public class RegUser {

	public String buyInsurance(QuoteBean quote) {

		// if(quote.getChassisNumber())
		// Add condition!

		boolean key1 = QuoteDao.findByChassisNo(quote.getChassisNumber());
		boolean key2 = QuoteDao.findByEngineNo(quote.getEngineNumber());
		if (quote.getPolicyType().equals("new")) {
			if (key1 && key2) {

				quote.setQuoteID(IdGenerator.genId());
				
				// String check = QuoteDao.save(quote);
				

				return "success";
			} else
				return "input";
		} else if (quote.getPolicyType().equals("renew")) {
			System.out.println("renew");
			if ((!(key1)) && (!(key2))) {

				quote.setQuoteID(IdGenerator.genId());
				
				return "success";
			} else
				return "input";
		}
		return "input";

	}

	public QuoteBean findQuote(Long quoteID) {

		QuoteBean quote = QuoteDao.findById(quoteID);

		return quote;

	}

	public DriverBean findDriver(Long driverID) {

		DriverBean driver = DriverDao.findById(driverID);

		return driver;

	}

	public String addDriver(DriverBean driver) {

		driver.setDriverID(IdGenerator.genId());
		String check = DriverDao.save(driver);

		if (check.equals("success")) {
			return "success";
		} else
			return "input";
	}

	public String checkDriver(Long quoteID) {

		int driverCount = DriverDao.countDriver(quoteID);

		if (driverCount < 4) {
			return "success";
		} else
			return "input";
	}

	public String modifyDriver(DriverBean driver) {

		String check = DriverDao.update(driver);

		if (check.equals("success"))
			return "success";
		else
			return "input";
	}

	public String deleteDriver(Long driverID) {

		String check = DriverDao.delete(driverID);

		if (check.equals("success"))
			return "success";
		else
			return "input";
	}

	public String changePassword(LoginBean login, String cpass) {

		String Response = LoginDao.updatePassword(login, cpass);

		if (Response.equals("success"))
			return "success";
		else
			return "input";
	}

	public ArrayList<DriverBean> userFindAll(Long quoteID) {

		ArrayList<DriverBean> DList = new ArrayList<DriverBean>();
		DList = DriverDao.findAll(quoteID);
		return DList;

	}

	public ArrayList<QuoteBean> userFindAllQuotes(Long quoteID) {

		ArrayList<QuoteBean> QList = new ArrayList<QuoteBean>();
		QList = QuoteDao.findAllUserQuotes(quoteID);
		
		return QList;

	}

	public String paymentCheque(ChequeBean cheque, Long userID, QuoteBean quote) {

		RegUser user = UserFactory.createUser();
		DriverBean driver = BeanFactory.getDriverBean();

		String check = QuoteDao.save(quote);

		if (check.equals("success")) {
			cheque.setPnino(IdGenerator.genId());
			String check1 = ChequeDao.save(cheque);

			if (check1.equals("success")) {
				System.out.println("success1");

				UserBean user1 = UserDao.findById(quote.getUserID());
				

				
				driver.setAddress(user1.getAddress());
				driver.setAge(user1.getAge());
				driver.setEmail(user1.getEmail());
				driver.setFirstName(user1.getFirstName());
				driver.setGender(user1.getGender());
				driver.setLastName(user1.getLastName());
				driver.setPhoneNo(user1.getPhoneNo());
				driver.setQuoteID(quote.getQuoteID());

				
				String check2 = user.addDriver(driver);

				if (check2.equals("success")) {
					return "success";
				}
			}
		}

		return "input";
	}

	public String paymentCredit(CreditBean credit, Long userID, QuoteBean quote) {

		RegUser user = UserFactory.createUser();
		DriverBean driver = BeanFactory.getDriverBean();

		String check = QuoteDao.save(quote);

		if (check.equals("success")) {
			credit.setPnino(IdGenerator.genId());
			String check1 = CreditDao.save(credit);

			if (check1.equals("success")) {
				
				
				UserBean user1 = UserDao.findById(quote.getUserID());
				
				driver.setAddress(user1.getAddress());
				driver.setAge(user1.getAge());
				driver.setEmail(user1.getEmail());
				driver.setFirstName(user1.getFirstName());
				driver.setGender(user1.getGender());
				driver.setLastName(user1.getLastName());
				driver.setPhoneNo(user1.getPhoneNo());
				driver.setQuoteID(quote.getQuoteID());

				
				String check2 = user.addDriver(driver);

				if (check2.equals("success")) {
					return "success";
				}
			}
		}

		return "input";
	}

	public ChequeBean findCheque(Long quoteID) {

		ChequeBean cheque = ChequeDao.findById(quoteID);

		return cheque;

	}

	public CreditBean findCredit(Long quoteID) {

		CreditBean credit = CreditDao.findById(quoteID);

		return credit;

	}

	public String logout(LoginBean login) {

		return (LoginDao.updateStatus(login));

	}
}
