package com.aiqs.domain;

public class UserFactory {

	public static SiteUser createSiteUser() {
		return new SiteUser();
	}

	public static RegUser createUser() {
		return new RegUser();
	}

	public static Admin createAdmin() {
		return new Admin();
	}
}
