package com.aiqs.domain;

import com.aiqs.bean.BeanFactory;
import com.aiqs.bean.LoginBean;
import com.aiqs.bean.UserBean;
import com.aiqs.dao.LoginDao;
import com.aiqs.dao.UserDao;
import com.aiqs.util.IdGenerator;

public class SiteUser {

	public String checkCredential(LoginBean login) {

		String check = "error";
		LoginBean login1 = LoginDao.findById(login.getUserId());

		if (login1 != null) {
			if (login1.getPassword().equals(login.getPassword())) {
				if (login1.getUserType().equals(login.getUserType())) {
					if (login1.getLoginStatus().equals("OFF")) {
						if (login1.getUserType().equals("admin")) {
							LoginDao.updateStatus(login1);
							check = "admin";
						} else if (login1.getUserType().equals("user")) {
							LoginDao.updateStatus(login1);
							check = "success";
						}
					} else {
						check = "Logged in from another system";
					}

				} else
					check = "User type doesnot match";
			} else
				check = "password doesnot match";
		} else
			check = "UserID doesnot match";

		return check;
	}

	public String register(UserBean user) {

		String key1 = null;
		String key2 = null;
		LoginBean login = BeanFactory.getLoginBean();

		login.setPassword(user.getPassword());
		login.setUserId(IdGenerator.genId());

		user.setUserId(IdGenerator.getCurrentUniqueid());

		key1 = UserDao.save(user);

		if (key1.equals("success")) {
			key2 = LoginDao.save(login);
		}

		if (key1.equals("success") && key2.equals("success"))
			return "success";

		else
			return "input";

	}
}