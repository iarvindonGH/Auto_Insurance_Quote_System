package com.aiqs.bean;

import java.util.Date;

public class QuoteBean {
	private Long userID;
	private Long quoteID;
	private String policyType;
	private Date policyStartDate;
	private Date previousPolicyExpiryDate;
	private String vehicleMake;
	private String vehicleModel;
	private String vehicleNumber;
	private Date yearOfManufacture;
	private Date dateOfRegistration;
	private String stateOfRegistration;
	private String cityOfRegistration;
	private String fuelType;
	private Long showRoomPrice;
	private Date dobOfOwner;
	private String professionOfOwner;
	private String insuranceProvider;

	private Long premiumAmount;
	private Long engineNumber;
	private String chassisNumber;
	private String panNumber;
	private String mailingAddress;
	private String paymentOption;

	public Long getUserID() {
		return userID;
	}

	public void setUserID(Long userID) {
		this.userID = userID;
	}

	public Long getQuoteID() {
		return quoteID;
	}

	public void setQuoteID(Long quoteID) {
		this.quoteID = quoteID;
	}

	public String getPolicyType() {
		return policyType;
	}

	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}

	public Date getPolicyStartDate() {
		return policyStartDate;
	}

	public void setPolicyStartDate(Date policyStartDate) {
		this.policyStartDate = policyStartDate;
	}

	public Date getPreviousPolicyExpiryDate() {
		return previousPolicyExpiryDate;
	}

	public void setPreviousPolicyExpiryDate(Date previousPolicyExpiryDate) {
		this.previousPolicyExpiryDate = previousPolicyExpiryDate;
	}

	public String getVehicleMake() {
		return vehicleMake;
	}

	public void setVehicleMake(String vehicleMake) {
		this.vehicleMake = vehicleMake;
	}

	public String getVehicleModel() {
		return vehicleModel;
	}

	public void setVehicleModel(String vehicleModel) {
		this.vehicleModel = vehicleModel;
	}

	public String getVehicleNumber() {
		return vehicleNumber;
	}

	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}

	public Date getYearOfManufacture() {
		return yearOfManufacture;
	}

	public void setYearOfManufacture(Date yearOfManufacture) {
		this.yearOfManufacture = yearOfManufacture;
	}

	public Date getDateOfRegistration() {
		return dateOfRegistration;
	}

	public void setDateOfRegistration(Date dateOfRegistration) {
		this.dateOfRegistration = dateOfRegistration;
	}

	public String getStateOfRegistration() {
		return stateOfRegistration;
	}

	public void setStateOfRegistration(String stateOfRegistration) {
		this.stateOfRegistration = stateOfRegistration;
	}

	public String getCityOfRegistration() {
		return cityOfRegistration;
	}

	public void setCityOfRegistration(String cityOfRegistration) {
		this.cityOfRegistration = cityOfRegistration;
	}

	public String getFuelType() {
		return fuelType;
	}

	public void setFuelType(String fuelType) {
		this.fuelType = fuelType;
	}

	public Long getShowRoomPrice() {
		return showRoomPrice;
	}

	public void setShowRoomPrice(Long showRoomPrice) {
		this.showRoomPrice = showRoomPrice;
	}

	public Date getDobOfOwner() {
		return dobOfOwner;
	}

	public void setDobOfOwner(Date dobOfOwner) {
		this.dobOfOwner = dobOfOwner;
	}

	public String getProfessionOfOwner() {
		return professionOfOwner;
	}

	public void setProfessionOfOwner(String professionOfOwner) {
		this.professionOfOwner = professionOfOwner;
	}

	public String getInsuranceProvider() {
		return insuranceProvider;
	}

	public void setInsuranceProvider(String insuranceProvider) {
		this.insuranceProvider = insuranceProvider;
	}

	public Long getPremiumAmount() {
		return premiumAmount;
	}

	public void setPremiumAmount(Long premiumAmount) {
		this.premiumAmount = premiumAmount;
	}

	public Long getEngineNumber() {
		return engineNumber;
	}

	public void setEngineNumber(Long engineNumber) {
		this.engineNumber = engineNumber;
	}

	public String getChassisNumber() {
		return chassisNumber;
	}

	public void setChassisNumber(String chassisNumber) {
		this.chassisNumber = chassisNumber;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getMailingAddress() {
		return mailingAddress;
	}

	public void setMailingAddress(String mailingAddress) {
		this.mailingAddress = mailingAddress;
	}

	public String getPaymentOption() {
		return paymentOption;
	}

	public void setPaymentOption(String paymentOption) {
		this.paymentOption = paymentOption;
	}

}
