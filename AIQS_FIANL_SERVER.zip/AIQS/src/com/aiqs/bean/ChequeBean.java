package com.aiqs.bean;

import java.util.Date;

public class ChequeBean {

	private Long pnino;
	private Long quoteId;
	private Date chequePickUpDate;
	private String preferredTime;

	public Long getPnino() {
		return pnino;
	}

	public void setPnino(Long pnino) {
		this.pnino = pnino;
	}

	public Long getQuoteId() {
		return quoteId;
	}

	public void setQuoteId(Long quoteId) {
		this.quoteId = quoteId;
	}

	public Date getChequePickUpDate() {
		return chequePickUpDate;
	}

	public void setChequePickUpDate(Date chequePickUpDate) {
		this.chequePickUpDate = chequePickUpDate;
	}

	public String getPreferredTime() {
		return preferredTime;
	}

	public void setPreferredTime(String preferredTime) {
		this.preferredTime = preferredTime;
	}

}
