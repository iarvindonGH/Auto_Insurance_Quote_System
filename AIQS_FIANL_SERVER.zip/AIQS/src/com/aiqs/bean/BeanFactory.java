package com.aiqs.bean;

public class BeanFactory {

	public static LoginBean getLoginBean() {
		return new LoginBean();
	}

	public static CreditBean getCreditBean() {
		return new CreditBean();
	}

	public static ChequeBean getChequeBean() {
		return new ChequeBean();
	}

	public static QuoteBean getQuoteBean() {
		return new QuoteBean();
	}

	public static DriverBean getDriverBean() {
		return new DriverBean();
	}

	public static UserBean getUserBean() {
		return new UserBean();
	}

}
