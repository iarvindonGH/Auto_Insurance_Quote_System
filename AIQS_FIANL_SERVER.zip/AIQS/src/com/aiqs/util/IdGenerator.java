package com.aiqs.util;

import java.sql.ResultSet;
import java.sql.SQLException;

public class IdGenerator {
	final static String IdQuery = "SELECT aiqs_seq.NEXTVAL FROM DUAL";
	final static String CurrentIdQuery = "SELECT aiqs_seq.CURRVAL FROM DUAL";

	private static long getUniqueid() {
		long Uniqueid = 0;
		ResultSet rs = null;
		try {
			rs = DBConnection.getConnection().createStatement()
					.executeQuery(IdQuery);
			while (rs.next()) {
				Uniqueid = rs.getLong(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return Uniqueid;
	}

	public static long getCurrentUniqueid() {
		long CurrentUniqueid = 0;
		ResultSet rs = null;
		try {
			rs = DBConnection.getConnection().createStatement()
					.executeQuery(CurrentIdQuery);
			while (rs.next()) {
				CurrentUniqueid = rs.getLong(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return CurrentUniqueid;

	}

	public static Long genId() {
		Long newUserId = null;
		Long Numeric = 0L;

		Numeric = getUniqueid();
		newUserId = Numeric;

		return newUserId;
	}
}
