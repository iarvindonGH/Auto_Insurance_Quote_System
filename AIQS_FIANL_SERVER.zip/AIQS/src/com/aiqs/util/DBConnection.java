package com.aiqs.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

	private static String ConnectionType = "STATIC";

	private static String DriverName = "oracle.jdbc.driver.OracleDriver";
	private static String DriverType = "jdbc:oracle:thin:";
	private static String Host = "localhost";
	private static String Port = "1521";
	private static String Sid = "xe";
	private static String UserName = "hr";
	private static String Password = "hr";
	private static Connection con;

	public static String getUserName() {
		return UserName;
	}

	public static void setUserName(String userName) {
		UserName = userName;
	}

	public static String getPassword() {
		return Password;
	}

	public static void setPassword(String password) {
		Password = password;
	}

	public static String getConnectionType() {
		return ConnectionType;
	}

	private static String getUrl() {
		return (DriverType + "@" + Host + ":" + Port + ":" + Sid);
	}

	public static Connection getConnection() {

		try {
			if (con == null || con.isClosed()) {

				try {
					Class.forName(DriverName).newInstance();
					con = DriverManager.getConnection(getUrl(), getUserName(),
							getPassword());
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return con;
	}

	public static void closeConnection() {
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void beginTransaction() {
		try {
			con.setAutoCommit(false);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void endTransaction() {
		try {
			con.setAutoCommit(true);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void rollbackTransaction() {
		try {
			con.rollback();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
