package com.aiqs.dao;

import static org.junit.Assert.assertEquals;

import java.sql.Connection;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.aiqs.bean.BeanFactory;
import com.aiqs.bean.UserBean;
import com.aiqs.util.DBConnection;

public class UserDaoDeleteTest {
	static Connection con;
	UserBean user;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		DBConnection.getConnection();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		DBConnection.closeConnection();
	}

	@Before
	public void setUp() throws Exception {
		user = BeanFactory.getUserBean();

		user.setUserId(1234L);
		user.setAddress("Pune");
		user.setAge(25);
		user.setEmail("a@gmail.com");
		user.setFirstName("Arvind");
		user.setLastName("Kumar");
		user.setGender("Male");
		user.setPhoneNo(1234567890L);

		UserDao.save(user);

	}

	@After
	public void tearDown() throws Exception {
		UserDao.delete(1234L);
	}

	@Test
	public void testDelete() {
		String Response = UserDao.delete(1234L);
		assertEquals("success", Response);

	}
}
