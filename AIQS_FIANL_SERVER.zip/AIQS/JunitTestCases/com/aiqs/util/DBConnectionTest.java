package com.aiqs.util;

import static org.junit.Assert.assertEquals;

import java.sql.Connection;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class DBConnectionTest {
	Connection con;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		con = DBConnection.getConnection();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetNewConnection() {

		Connection con2 = DBConnection.getConnection();
		assertEquals(con2, con);

	}

}
