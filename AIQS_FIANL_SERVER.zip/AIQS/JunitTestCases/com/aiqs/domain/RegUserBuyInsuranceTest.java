package com.aiqs.domain;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.aiqs.bean.BeanFactory;
import com.aiqs.bean.QuoteBean;
import com.aiqs.bean.UserBean;
import com.aiqs.dao.QuoteDao;
import com.aiqs.dao.UserDao;

public class RegUserBuyInsuranceTest {
	QuoteBean quote1;
	QuoteBean quote;
	UserBean user;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		user = BeanFactory.getUserBean();
		quote1 = BeanFactory.getQuoteBean();
		quote = BeanFactory.getQuoteBean();

		user.setUserId(1234L);
		user.setAddress("Pune");
		user.setAge(25);
		user.setEmail("a@gmail.com");
		user.setFirstName("Arvind");
		user.setLastName("Kumar");
		user.setGender("Male");
		user.setPhoneNo(1234567890L);

		quote1.setChassisNumber("ASD1234");
		quote1.setCityOfRegistration("Pune");
		quote1.setDateOfRegistration(new java.util.Date());
		quote1.setDobOfOwner(new java.util.Date());
		quote1.setEngineNumber(123456L);
		quote1.setFuelType("Petrol");
		quote1.setInsuranceProvider("ABC");
		quote1.setMailingAddress("Pune");
		quote1.setPanNumber("AEPHN1234A");
		quote1.setPaymentOption("Cheque");
		quote1.setPolicyStartDate(new java.util.Date());
		quote1.setPolicyType("Premium");
		quote1.setPremiumAmount(45000L);
		quote1.setPreviousPolicyExpiryDate(new java.util.Date());
		quote1.setProfessionOfOwner("Services");
		quote1.setQuoteID(9000L);
		quote1.setShowRoomPrice(3000000L);
		quote1.setStateOfRegistration("Maharastra");
		quote1.setUserID(1234L);
		quote1.setVehicleMake("Maruti");
		quote1.setVehicleModel("Maruti800");
		quote1.setVehicleNumber("MH-14-AE-2345");
		quote1.setYearOfManufacture(new java.util.Date());

		quote.setChassisNumber("ASD12345");
		quote.setCityOfRegistration("Pune");
		quote.setDateOfRegistration(new java.util.Date());
		quote.setDobOfOwner(new java.util.Date());
		quote.setEngineNumber(12345654L);
		quote.setFuelType("Petrol");
		quote.setInsuranceProvider("ABC");
		quote.setMailingAddress("Pune");
		quote.setPanNumber("AEPHN1234A");
		quote.setPaymentOption("Cheque");
		quote.setPolicyStartDate(new java.util.Date());
		quote.setPolicyType("Premium");
		quote.setPremiumAmount(45000L);
		quote.setPreviousPolicyExpiryDate(new java.util.Date());
		quote.setProfessionOfOwner("Services");
		// quote.setQuoteID(9001L);
		quote.setShowRoomPrice(3000000L);
		quote.setStateOfRegistration("Maharastra");
		quote.setUserID(1234L);
		quote.setVehicleMake("Maruti");
		quote.setVehicleModel("Maruti800");
		quote.setVehicleNumber("MH-14-AE-2345");
		quote.setYearOfManufacture(new java.util.Date());

		UserDao.save(user);
		QuoteDao.save(quote1);
	}

	@After
	public void tearDown() throws Exception {
		UserDao.delete(1234L);
	}

	@Test
	public void testRegUserBuyInsurance() {
		RegUser regUser = new RegUser();
		String Response = regUser.buyInsurance(quote);

		if (Response.equals("success")) {
			assertEquals("success", Response);

		}

		Response = regUser.buyInsurance(quote);

		if (Response.equals("Vehicle already registered")) {
			assertEquals("Vehicle already registered", Response);

		}
		if (Response.equals("input")) {
			assertEquals("input", Response);

		}

		if (Response.equals("Driver not added")) {
			assertEquals("Driver not added", Response);

		}

	}
}
