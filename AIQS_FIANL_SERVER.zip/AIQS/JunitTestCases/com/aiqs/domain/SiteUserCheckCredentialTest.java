package com.aiqs.domain;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.aiqs.bean.BeanFactory;
import com.aiqs.bean.LoginBean;
import com.aiqs.bean.UserBean;
import com.aiqs.dao.LoginDao;
import com.aiqs.dao.UserDao;

public class SiteUserCheckCredentialTest {
	UserBean user;
	UserBean user1;
	LoginBean login;
	LoginBean login1;
	LoginBean login2;
	LoginBean login3;
	LoginBean loginAdmin;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		user = BeanFactory.getUserBean();
		user1 = BeanFactory.getUserBean();
		login = BeanFactory.getLoginBean();
		login1 = BeanFactory.getLoginBean();
		login2 = BeanFactory.getLoginBean();
		login3 = BeanFactory.getLoginBean();
		loginAdmin = BeanFactory.getLoginBean();

		user.setUserId(1234L);
		user.setAddress("Pune");
		user.setAge(25);
		user.setEmail("a@gmail.com");
		user.setFirstName("Arvind");
		user.setLastName("Kumar");
		user.setGender("Male");
		user.setPhoneNo(1234567890L);
		UserDao.save(user);

		user1.setUserId(1234567890L);
		user1.setAddress("Pune");
		user1.setAge(25);
		user1.setEmail("a@gmail.com");
		user1.setFirstName("Arvind");
		user1.setLastName("Kumar");
		user1.setGender("Male");
		user1.setPhoneNo(1234567890L);
		UserDao.save(user1);

		login.setUserId(1234L);
		login.setPassword("secret");
		login.setUserType("user");
		LoginDao.save(login);

		loginAdmin.setUserId(1234567890L);
		loginAdmin.setPassword("secret1");
		loginAdmin.setUserType("admin");
		LoginDao.save(loginAdmin);

		login1.setUserId(123456L);
		login1.setPassword("secret");
		login1.setUserType("user");

		login2.setUserId(1234L);
		login2.setPassword("secret1");
		login2.setUserType("user");

		login3.setUserId(1234L);
		login3.setPassword("secret");
		login3.setUserType("user2");

	}

	@After
	public void tearDown() throws Exception {

		UserDao.delete(user.getUserId());
		// UserDao.delete(user1.getUserId());
	}

	@Test
	public void testAdminChangePassword() {
		SiteUser siteUser = new SiteUser();
		String Response;

		Response = siteUser.checkCredential(login1);
		if (Response.equals("UserID doesnot match")) {
			assertEquals("UserID doesnot match", Response);
			System.out.println("UserID doesnot match");
		}

		Response = siteUser.checkCredential(login2);
		if (Response.equals("password doesnot match")) {
			assertEquals("password doesnot match", Response);
			System.out.println("password doesnot match");
		}

		Response = siteUser.checkCredential(login3);
		if (Response.equals("User type doesnot match")) {
			assertEquals("User type doesnot match", Response);
			System.out.println("User type doesnot match");
		}

		/*
		 * Response = siteUser.checkCredential(login);
		 * System.out.println(Response);
		 * 
		 * if(Response.equals("Logged in from another system")){
		 * assertEquals("Logged in from another system", Response);
		 * System.out.println("Logged in from another system"); }
		 */

		Response = siteUser.checkCredential(login);
		System.out.println(Response);
		if (Response.equals("success")) {
			assertEquals("success", Response);
			System.out.println("Logged in successful as user");
		}

		Response = siteUser.checkCredential(loginAdmin);
		System.out.println(Response);
		if (Response.equals("admin")) {
			assertEquals("admin", Response);
			System.out.println("Logged in successful as Admin");
		}

	}
}
