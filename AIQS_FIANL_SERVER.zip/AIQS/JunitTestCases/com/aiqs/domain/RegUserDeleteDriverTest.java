package com.aiqs.domain;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.aiqs.bean.BeanFactory;
import com.aiqs.bean.DriverBean;
import com.aiqs.bean.QuoteBean;
import com.aiqs.bean.UserBean;
import com.aiqs.dao.DriverDao;
import com.aiqs.dao.QuoteDao;
import com.aiqs.dao.UserDao;

public class RegUserDeleteDriverTest {
	DriverBean driver;
	QuoteBean quote;
	UserBean user;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		driver = BeanFactory.getDriverBean();
		quote = BeanFactory.getQuoteBean();
		user = BeanFactory.getUserBean();

		user.setUserId(1234L);
		user.setAddress("Pune");
		user.setAge(25);
		user.setEmail("a@gmail.com");
		user.setFirstName("Arvind");
		user.setLastName("Kumar");
		user.setGender("Male");
		user.setPhoneNo(1234567890L);

		quote.setChassisNumber("ASD1234");
		quote.setCityOfRegistration("Pune");
		quote.setDateOfRegistration(new java.util.Date());
		quote.setDobOfOwner(new java.util.Date());
		quote.setEngineNumber(123456L);
		quote.setFuelType("Petrol");
		quote.setInsuranceProvider("ABC");
		quote.setMailingAddress("Pune");
		quote.setPanNumber("AEPHN1234A");
		quote.setPaymentOption("Cheque");
		quote.setPolicyStartDate(new java.util.Date());
		quote.setPolicyType("Premium");
		quote.setPremiumAmount(45000L);
		quote.setPreviousPolicyExpiryDate(new java.util.Date());
		quote.setProfessionOfOwner("Services");
		quote.setQuoteID(9000L);
		quote.setShowRoomPrice(3000000L);
		quote.setStateOfRegistration("Maharastra");
		quote.setUserID(1234L);
		quote.setVehicleMake("Maruti");
		quote.setVehicleModel("Maruti800");
		quote.setVehicleNumber("MH-14-AE-2345");
		quote.setYearOfManufacture(new java.util.Date());

		driver.setDriverID(12345L);
		driver.setFirstName("Aqib");
		driver.setLastName("mushtaq");
		driver.setAge(22);
		driver.setGender("Male");
		driver.setAddress("pune");
		driver.setPhoneNo(1234567890L);
		driver.setEmail("a@gmail.com");
		driver.setQuoteID(9000L);

		UserDao.save(user);
		QuoteDao.save(quote);
		DriverDao.save(driver);
	}

	@After
	public void tearDown() throws Exception {

		UserDao.delete(1234L);
	}

	@Test
	public void testRegUserDeleteDriver() {
		RegUser regUser = new RegUser();
		String Response = regUser.deleteDriver(12345L);
		assertEquals("success", Response);

	}
}
