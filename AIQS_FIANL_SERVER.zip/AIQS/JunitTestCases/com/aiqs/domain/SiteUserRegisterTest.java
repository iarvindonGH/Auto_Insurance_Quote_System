package com.aiqs.domain;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.aiqs.bean.BeanFactory;
import com.aiqs.bean.UserBean;
import com.aiqs.dao.UserDao;

public class SiteUserRegisterTest {
	UserBean user;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		user = BeanFactory.getUserBean();

		user.setAddress("Pune");
		user.setAge(25);
		user.setEmail("a@gmail.com");
		user.setFirstName("Arvind");
		user.setLastName("Kumar");
		user.setGender("Male");
		user.setPassword("sectret");
		user.setPhoneNo(1234567890L);

	}

	@After
	public void tearDown() throws Exception {

		UserDao.delete(user.getUserId());
	}

	@Test
	public void testAdminChangePassword() {
		SiteUser siteUser = new SiteUser();

		String Response = siteUser.register(user);
		assertEquals("success", Response);

	}
}
